"use client";

import { useEffect } from "react";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <html>
      <body>
        <div className="mx-auto max-w-2xl p-10 text-center">
          <h1 className="text-2xl font-semibold">Er ging iets mis</h1>
          <p className="mt-2 text-neutral-600">
            Probeer het opnieuw of ga terug naar de homepage.
          </p>
          <div className="mt-6 flex justify-center gap-3">
            <button onClick={() => reset()} className="btn-ghost tap">
              Opnieuw proberen
            </button>
            <a href="/" className="btn-primary tap">
              Naar home
            </a>
          </div>
          {process.env.NODE_ENV !== "production" && error?.digest && (
            <p className="mt-4 text-xs text-neutral-400">Error code: {error.digest}</p>
          )}
        </div>
      </body>
    </html>
  );
}
