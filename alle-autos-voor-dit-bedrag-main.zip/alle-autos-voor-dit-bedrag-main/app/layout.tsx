// app/layout.tsx
import "./globals.css";
import type { Metadata, Viewport } from "next";

export const metadata: Metadata = {
  title: "Alle auto’s voor dit geld",
  description:
    "Tik een bedrag in en zie welke auto’s je ongeveer kunt kopen – op basis van RDW-steekproef en modellenlijst.",
  // >>> ZET HIER JE ECHTE DOMEIN <<<
  metadataBase: new URL("https://alleautosvoorditgeld.nl"),
  openGraph: {
    title: "Alle auto’s voor dit geld",
    description: "Zoek auto’s rond jouw budget. RDW steekproef + modellenlijst.",
    url: "https://alleautosvoorditgeld.nl",
    siteName: "Alle auto’s voor dit geld",
    images: [{ url: "/logo.png?v=2", width: 800, height: 800, alt: "Logo" }],
    locale: "nl_NL",
    type: "website",
  },
  twitter: {
    card: "summary",
    title: "Alle auto’s voor dit geld",
    description: "Zoek auto’s rond jouw budget. RDW steekproef + modellenlijst.",
    images: ["/logo.png?v=2"],
  },
  // Laat Next de juiste <link rel="icon"> genereren
  icons: {
    icon: "/logo.png?v=2",
    apple: "/logo.png?v=2",
    shortcut: "/logo.png?v=2",
  },
  manifest: "/site.webmanifest",
};

// verplaatst van metadata.themeColor naar viewport (Next 14)
export const viewport: Viewport = { themeColor: "#ffffff" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="nl">
      <head>
        {/* Extra defensief: preconnects voor de image proxy-bronnen */}
        <link rel="preconnect" href="https://upload.wikimedia.org" crossOrigin="" />
        <link rel="preconnect" href="https://commons.wikimedia.org" crossOrigin="" />
        <link rel="preconnect" href="https://en.wikipedia.org" crossOrigin="" />
        <link rel="preconnect" href="https://nl.wikipedia.org" crossOrigin="" />
      </head>
      <body className="min-h-screen bg-white text-neutral-900 antialiased">{children}</body>
    </html>
  );
}
