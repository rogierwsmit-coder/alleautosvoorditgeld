// app/about/page.tsx
import type { Metadata } from "next";
import Link from "next/link";
import JsonLd from "../../components/JsonLd";

export const metadata: Metadata = {
  title: "Over",
  description:
    "Alle auto’s voor dit geld is de eenvoudigste manier om auto’s te vinden voor een exact bedrag. Transparant, snel en zonder ruis.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  const baseUrl =
    process.env.NEXT_PUBLIC_SITE_URL ?? "https://alleautosvoorditgeld.nl";

  const orgLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Alle auto’s voor dit geld",
    url: baseUrl,
    logo: `${baseUrl}/favicon.svg`,
    description:
      "Zoekmachine die exact de auto’s toont voor het bedrag dat jij invult.",
  };

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: [
      {
        "@type": "Question",
        name: "Wat maakt deze site anders?",
        acceptedAnswer: {
          "@type": "Answer",
          text:
            "Je zoekt niet op prijsbereiken, maar op één exact bedrag. Je ziet dus meteen de auto’s die echt binnen jouw budget passen.",
        },
      },
      {
        "@type": "Question",
        name: "Waar komen de resultaten vandaan?",
        acceptedAnswer: {
          "@type": "Answer",
          text:
            "Van publieke bronnen en aangeleverde feeds. Dealers kunnen eenvoudig een CSV of Google Sheet koppelen.",
        },
      },
      {
        "@type": "Question",
        name: "Is de service gratis?",
        acceptedAnswer: {
          "@type": "Answer",
          text:
            "Zoeken is gratis. Voor aanbieders komen er opties om voorraad te uploaden en extra zichtbaarheid te krijgen.",
        },
      },
    ],
  };

  return (
    <main className="mx-auto max-w-3xl p-6">
      <h1 className="text-3xl font-semibold">Over “Alle auto’s voor dit geld”</h1>
      <p className="mt-3 text-neutral-700 dark:text-neutral-300">
        Deze site is gemaakt om <strong>zéér laagdrempelig</strong> de auto te
        vinden die past bij <strong>precies jouw bedrag</strong>. Geen ruis, geen
        ingewikkelde filters — je vult een bedrag in en je krijgt direct een
        lijst met treffers.
      </p>

      <section className="mt-6 grid gap-4 sm:grid-cols-3">
        <div className="interactive-card p-4">
          <h3 className="font-medium">Exact bedrag</h3>
          <p className="mt-1 text-sm text-neutral-600 dark:text-neutral-300">
            Eén bedrag in, exacte resultaten eruit. Supersimpel.
          </p>
        </div>
        <div className="interactive-card p-4">
          <h3 className="font-medium">Transparant</h3>
          <p className="mt-1 text-sm text-neutral-600 dark:text-neutral-300">
            Geen verborgen filters of paywalls. Jij houdt de regie.
          </p>
        </div>
        <div className="interactive-card p-4">
          <h3 className="font-medium">Voor kopers & dealers</h3>
          <p className="mt-1 text-sm text-neutral-600 dark:text-neutral-300">
            Kopers zoeken makkelijk; dealers kunnen straks feeds uploaden.
          </p>
        </div>
      </section>

      <div className="mt-8">
        <Link href="/" className="btn-primary tap">Zoek nu op exact bedrag</Link>
      </div>

      <JsonLd data={orgLd} />
      <JsonLd data={faqLd} />
    </main>
  );
}
