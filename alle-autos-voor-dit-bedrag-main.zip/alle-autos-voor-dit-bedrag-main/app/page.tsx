"use client";

import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";

/* ------------ Types ------------ */
type Suggestion = {
  merk: string;
  model: string;
  year: number;
  estimated_price: number;
  catalogus: number | null;
  age: number | null;
  rdw_kenteken: string | null;
  source?: "candidate" | "bulk";
};

/* ------------ Motorfilters ------------ */
const MOTOR_BRANDS = new Set<string>([
  "YAMAHA","SUZUKI","KAWASAKI","TRIUMPH","DUCATI","HARLEY-DAVIDSON","HARLEY DAVIDSON",
  "PIAGGIO","VESPA","KTM","APRILIA","HUSQVARNA","ROYAL ENFIELD","INDIAN","MOTO GUZZI",
  "SYM","KYMCO","BENELLI","CF MOTO","CFMOTO","BETA","GASGAS","ZERO","BUELL",
]);

const MOTOR_MODEL_REGEX =
  /\b(?:(?:R|F)\s?\d{3,4}|CBR|CB\s?\d{1,4}|GSX|V-?STROM|NINJA|DUKE|ADVENTURE|XSR|MT-?\d{1,3}|YZF|PANIGALE|MONSTER|HYPERMOTARD|SCRAMBLER|TRIDENT|TIGER|SPEED\s?TRIPLE|STREET\s?TRIPLE|BONNEVILLE)\b/i;

/** Gewijzigd: Honda motorreeksen (zonder \b na prefix; matcht ook CB1000RA, CB500X, etc.) */
const HONDA_BIKE_PREFIXES =
  /^(?:CBR?|CBF|CRF|NC|VFR|X-?ADV|PCX|MSX|GROM|FORZA|SH|GL|GOLD\s?WING)/i;

function isTwoWheeler(r: Suggestion): boolean {
  const brand = (r.merk || "").toUpperCase();
  if (MOTOR_BRANDS.has(brand)) return true;

  const modelRaw = (r.model || "").trim();
  const model = modelRaw.toUpperCase();

  // Honda – herken veelvoorkomende motorreeksen (auto’s zoals CR-V/HR-V/CIVIC vallen hier niet onder)
  if (brand === "HONDA" && HONDA_BIKE_PREFIXES.test(modelRaw)) return true;

  if (MOTOR_MODEL_REGEX.test(model)) return true;

  // NL motorfietskenteken start met 'M'
  const k = (r.rdw_kenteken || "").replace(/-/g, "").toUpperCase();
  if (k && k.startsWith("M")) return true;

  return false;
}

/* ------------ Bestelbus/pick-up filter ------------ */
const VAN_PICKUP_KEYWORDS = [
  "TRANSIT","TRANSIT CUSTOM","TRANSIT CONNECT",
  "SPRINTER","CRAFTER",
  "DUCATO","BOXER","JUMPER",
  "MASTER","MOVANO",
  "VIVARO","TRAFIC",
  "EXPERT","JUMPY","SCUDO",
  "CADDY","CADDY CARGO",
  "TRANSPORTER","MULTIVAN","CARAVELLE",
  "VITO","V-KLASSE","V KLASSE","VIANO",
  "IVECO","DAILY",
  "BERLINGO","PARTNER","KANGOO","COMBO","DOBLO","FIORINO","BIPPER",
  "HIACE","PROACE",
  "NV200","NV250","NV300","NV400",
  "HILUX","RANGER","NAVARA","AMAROK","L200","D-MAX","D MAX","BT-50","BT50","TUNDRA","TACOMA",
];
function isCommercialVehicle(r: Suggestion): boolean {
  const x = `${(r.merk || "").toUpperCase()} ${(r.model || "").toUpperCase()}`;
  return VAN_PICKUP_KEYWORDS.some((k) => x.includes(k));
}

/* ------------ Prijsvenster (alleen eronder) ------------ */
function priceWindow(budget: number) {
  const belowDefault = Math.max(750, Math.round(budget * 0.2));
  return { min: Math.max(0, budget - belowDefault), max: budget };
}
function widerPriceWindow(budget: number) {
  const belowWide = Math.max(1500, Math.round(budget * 0.35));
  return { min: Math.max(0, budget - belowWide), max: budget };
}
function inWindow(p: number | null | undefined, win: {min:number,max:number}) {
  const v = p ?? 0;
  return v >= win.min && v <= win.max;
}

/* ---------------- Image-query builder (zachte hints) ---------------- */
function buildImageQueries(r: Suggestion): string[] {
  const brand = (r.merk || "").trim();
  const model = (r.model || "").trim();
  const year  = String(r.year || "");

  const upperBrand = brand.toUpperCase();
  const upperModel = model.toUpperCase();

  const joinq = (...parts: string[]) =>
    parts.map((p) => p.trim()).filter(Boolean).join(", ");

  const hints: string[] = [];

  if (upperBrand.includes("MERCEDES") && /\bGLC\b/.test(upperModel)) {
    hints.push("GLC-Class", "X253", "SUV", "passenger car");
  }
  if (upperBrand === "LAND ROVER" && /\bRANGE ROVER\b/.test(upperModel) && !/\bSPORT\b/.test(upperModel)) {
    hints.push("Range Rover", "L405", "SUV", "passenger car");
  }
  if (upperBrand === "LAND ROVER" && /\bRANGE ROVER SPORT\b/.test(upperModel)) {
    hints.push("Range Rover Sport", "L494", "SUV", "passenger car");
  }
  if (upperBrand === "MINI" && /COUNTRYMAN/.test(upperModel)) {
    hints.push("F60");
  }

  const hintFront =
    upperBrand === "BMW" || upperBrand === "AUDI" || upperBrand === "VOLKSWAGEN" || upperBrand === "VW"
      ? "front three quarter"
      : "";
  if (hintFront) hints.push(hintFront);

  const queries = [
    joinq(brand, model, year, "car", ...hints),
    joinq(brand, model, "car", ...hints),
    joinq(brand, "SUV", year, "car", ...hints),
    joinq(brand, model),
  ];

  return Array.from(new Set(queries));
}

/* ------------ Image proxy helper ------------ */
function imgProxyUrl(r: Suggestion, idx: number) {
  const queries = buildImageQueries(r);
  const q = queries[0];
  return `/api/car-image?q=${encodeURIComponent(q)}&sig=${idx}&strict=1`;
}

/* ------------ Skeleton ------------ */
function CardSkeleton() {
  return (
    <article className="overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-sm">
      <div className="flex animate-pulse">
        <div className="h-40 w-1/2 min-w-[48%] bg-neutral-100 sm:h-48 md:h-52" />
        <div className="w-1/2 p-4">
          <div className="h-3 w-24 rounded bg-neutral-200" />
          <div className="mt-2 h-5 w-40 rounded bg-neutral-200" />
          <div className="mt-3 h-4 w-32 rounded bg-neutral-200" />
          <div className="mt-2 h-3 w-44 rounded bg-neutral-200" />
          <div className="mt-3 h-6 w-24 rounded-full bg-neutral-200" />
        </div>
      </div>
    </article>
  );
}

/* ------------ Inner ------------ */
function PageInner() {
  const params = useSearchParams();

  const initial = params.get("amount") || "";
  const [amount, setAmount] = useState(initial);
  const [hideCommercial, setHideCommercial] = useState(true);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<Suggestion[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [warn, setWarn] = useState<string | null>(null);

  const lastRequestId = useRef(0);

  useEffect(() => {
    const q = amount.replace(/[^\d]/g, "");
    const url = q ? `/?amount=${q}` : "/";
    window.history.replaceState(null, "", url);
  }, [amount]);

  async function runSearch(qNum: number) {
    const myId = ++lastRequestId.current;

    try {
      setLoading(true);
      setError(null);
      setWarn(null);

      const res = await fetch(`/api/estimate-by-amount?amount=${qNum}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json?.error || "Zoekopdracht mislukt");

      const incoming: Suggestion[] = (json.data || []) as Suggestion[];

      // 1) motoren weg
      const noMotor = incoming.filter((r) => !isTwoWheeler(r));

      // 2) busjes volgens toggle
      const base = hideCommercial ? noMotor.filter((r) => !isCommercialVehicle(r)) : noMotor;

      // 3) prijsvenster (alleen eronder)
      const defaultWin = priceWindow(qNum);
      let filtered = base.filter((r) => inWindow(r.estimated_price, defaultWin));

      if (filtered.length < 6) {
        const wideWin = widerPriceWindow(qNum);
        const widened = base.filter((r) => inWindow(r.estimated_price, wideWin));
        if (widened.length > filtered.length) {
          filtered = widened;
          setWarn("Venster iets verruimd om meer resultaten te tonen (alleen onder budget).");
        }
      }

      if (myId !== lastRequestId.current) return;

      if (filtered.length === 0) {
        setResults([]);
        setError(
          "Geen goede matches rond dit bedrag. Probeer iets hoger bedrag of zet ‘Bedrijfswagens verbergen’ uit."
        );
        return;
      }

      // Dedup
      const seen = new Set<string>();
      const deduped: Suggestion[] = [];
      for (const r of filtered) {
        const k = `${(r.merk||"").toUpperCase()}|${(r.model||"").toUpperCase()}|${r.year}|${Math.round((r.estimated_price||0)/50)}`;
        if (!seen.has(k)) { seen.add(k); deduped.push(r); }
      }

      setResults(deduped);
    } catch (e: any) {
      if (myId !== lastRequestId.current) return;
      setResults([]);
      setError(e?.message || "Fout bij zoeken");
    } finally {
      if (myId === lastRequestId.current) setLoading(false);
    }
  }

  useEffect(() => {
    const q = amount.replace(/[^\d]/g, "");
    if (!q) {
      setResults([]);
      setError(null);
      setWarn(null);
      return;
    }
    const qNum = Number(q);
    const t = setTimeout(() => runSearch(qNum), 250);
    return () => clearTimeout(t);
  }, [amount, hideCommercial]);

  const budget = Number(amount.replace(/[^\d]/g, "")) || 0;
  const sorted = useMemo(() => {
    if (!results.length || !budget) return results;
    return [...results].sort((a, b) => {
      const da = Math.abs((a.estimated_price || 0) - budget);
      const db = Math.abs((b.estimated_price || 0) - budget);
      return da - db;
    });
  }, [results, budget]);

  return (
    <section className="pt-16 pb-12">
      <div className="text-center">
        <img src="/logo.png" alt="Alle auto’s voor dit geld" width={160} height={160} className="mx-auto mb-6" />
        <h1 className="text-4xl font-bold tracking-tight">Alle auto’s voor dit geld</h1>
        <p className="mt-2 text-lg text-neutral-600">
          Auto mag… <span className="italic">voor elk bedrag!</span>
        </p>

        <div className="mx-auto mt-8 w-full max-w-2xl">
          <div className="flex items-center gap-3 rounded-2xl border border-neutral-300 bg-white/80 p-2 shadow-sm backdrop-blur">
            <input
              id="amount"
              name="amount"
              type="text"
              inputMode="numeric"
              placeholder="Voer bedrag in (bijv. 5000)"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full rounded-xl px-4 py-3 text-base outline-none placeholder:text-neutral-400"
            />
            <button
              type="button"
              onClick={() => {
                const q = Number(amount.replace(/[^\d]/g, "")) || 0;
                if (q) runSearch(q);
              }}
              className="rounded-xl bg-black px-5 py-3 text-base font-medium text-white transition hover:shadow-[0_0_14px_rgba(0,0,0,0.25)]"
              title="Zoeken"
            >
              Zoeken
            </button>
          </div>

          <label className="mt-3 inline-flex select-none items-center gap-2 text-sm text-neutral-700">
            <input
              type="checkbox"
              checked={hideCommercial}
              onChange={(e) => setHideCommercial(e.target.checked)}
              className="h-4 w-4 rounded border-neutral-300"
            />
            Bedrijfswagens verbergen
          </label>
        </div>

        {warn && <p className="mt-3 text-sm text-amber-700">{warn}</p>}
        {error && <p className="mt-3 text-sm text-red-600">{error}</p>}
      </div>

      {loading && (
        <div className="mx-auto mt-10 grid max-w-5xl grid-cols-1 gap-5 sm:grid-cols-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {!loading && sorted.length > 0 && (
        <div className="mx-auto mt-10 grid max-w-5xl grid-cols-1 gap-5 sm:grid-cols-2">
          {sorted.map((r, idx) => {
            const title = `${r.merk} ${r.model} ${r.year}`;
            const imgUrl = imgProxyUrl(r, idx);
            const diff = Math.abs((r.estimated_price || 0) - budget);
            const best = budget ? diff <= Math.max(600, Math.round(budget * 0.05)) : false;

            return (
              <article key={`${title}-${idx}`} className="overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-sm">
                <div className="flex">
                  <div className="relative h-40 w-1/2 min-w-[48%] bg-neutral-100 sm:h-48 md:h-52">
                    <img
                      src={imgUrl}
                      alt={title}
                      loading="lazy"
                      className="h-full w-full object-cover"
                      onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = "none"; }}
                    />
                    {best && (
                      <span className="absolute left-2 top-2 rounded-full bg-emerald-600/90 px-2 py-1 text-xs font-medium text-white shadow">
                        Beste match
                      </span>
                    )}
                  </div>

                  <div className="w-1/2 p-4">
                    <div className="text-sm text-neutral-500">{r.merk}</div>
                    <h3 className="text-lg font-semibold leading-snug">
                      {r.model} • {r.year}
                    </h3>

                    <div className="mt-2 text-neutral-700">
                      Geschat: <strong>€{(r.estimated_price ?? 0).toLocaleString("nl-NL")}</strong>
                    </div>

                    {r.catalogus ? (
                      <div className="text-sm text-neutral-500">
                        Catalogus: €{r.catalogus.toLocaleString("nl-NL")} • Leeftijd: {r.age} jr
                      </div>
                    ) : (
                      <div className="text-sm text-neutral-500">Catalogusprijs onbekend</div>
                    )}

                    {r.source && (
                      <span className="mt-3 inline-block rounded-full border border-neutral-300 px-2 py-0.5 text-xs text-neutral-600">
                        {r.source === "candidate" ? "Populair model" : "RDW steekproef"}
                      </span>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
}

/* ------------ Suspense wrapper ------------ */
export default function Page() {
  return (
    <Suspense fallback={<div className="mx-auto mt-10 max-w-5xl">Bezig met laden…</div>}>
      <PageInner />
    </Suspense>
  );
}
