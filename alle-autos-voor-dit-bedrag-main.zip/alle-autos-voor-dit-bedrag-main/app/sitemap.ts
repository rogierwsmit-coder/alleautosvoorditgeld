// app/sitemap.ts
import type { MetadataRoute } from "next";

/**
 * Genereert de sitemap met absolute URLs.
 * Zorg dat in Vercel (Production) NEXT_PUBLIC_SITE_URL is gezet op:
 * https://alleautosvoorditgeld.nl
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const base =
    process.env.NEXT_PUBLIC_SITE_URL || "https://alleautosvoorditgeld.nl";
  const lastModified = new Date();

  const urls: MetadataRoute.Sitemap = [
    {
      url: `${base}/`,
      lastModified,
      changeFrequency: "daily",
      priority: 1.0,
    },
    {
      url: `${base}/about`,
      lastModified,
      changeFrequency: "yearly",
      priority: 0.5,
    },
    {
      url: `${base}/terms`,
      lastModified,
      changeFrequency: "yearly",
      priority: 0.3,
    },
    {
      url: `${base}/privacy`,
      lastModified,
      changeFrequency: "yearly",
      priority: 0.3,
    },
    {
      url: `${base}/cookies`,
      lastModified,
      changeFrequency: "yearly",
      priority: 0.2,
    },
    {
      url: `${base}/contact`,
      lastModified,
      changeFrequency: "yearly",
      priority: 0.2,
    },
  ];

  return urls;
}
