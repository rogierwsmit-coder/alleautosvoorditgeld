import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy",
  description: "Privacyverklaring van Alle auto’s voor dit geld.",
};

export default function PrivacyPage() {
  return (
    <div className="mx-auto max-w-3xl p-6 space-y-6">
      <h1 className="text-2xl font-semibold">Privacyverklaring</h1>
      <p className="text-sm text-neutral-500">
        <strong>Laatst bijgewerkt:</strong> 22 augustus 2025
      </p>

      <section className="space-y-2">
        <h2 className="font-semibold">1. Inleiding</h2>
        <p className="text-neutral-700">
          We hechten waarde aan jouw privacy. In deze verklaring lees je welke
          persoonsgegevens we (kunnen) verwerken, voor welke doeleinden en hoe
          we die beveiligen.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="font-semibold">2. Verwerkingsverantwoordelijke</h2>
        <p className="text-neutral-700">
          De verwerkingsverantwoordelijke voor de Website <em>alleautosvoorditgeld.nl</em>
          is “Alle auto’s voor dit geld”. Contactgegevens volgen zodra onze mailbox live is.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="font-semibold">3. Welke gegevens</h2>
        <ul className="list-disc pl-5 text-neutral-700">
          <li>Technische data (IP-adres, browser, apparaat, tijdstempels).</li>
          <li>Gebruik van de site (opgevraagde pagina’s, ingevoerde bedragen).</li>
          <li>Gegevens aangeleverd door aanbieders in hun feeds/CSV’s (voertuigdata).</li>
        </ul>
      </section>

      <section className="space-y-2">
        <h2 className="font-semibold">4. Doeleinden</h2>
        <ul className="list-disc pl-5 text-neutral-700">
          <li>Het tonen van voertuigen voor een exact bedrag.</li>
          <li>Beveiliging, statistiek en foutdiagnose.</li>
          <li>Verbetering van functies en gebruikerservaring.</li>
        </ul>
      </section>

      <section className="space-y-2">
        <h2 className="font-semibold">5. Bewaartermijnen</h2>
        <p className="text-neutral-700">
          We bewaren gegevens niet langer dan noodzakelijk, tenzij wettelijk vereist.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="font-semibold">6. Delen met derden</h2>
        <p className="text-neutral-700">
          We delen geen persoonsgegevens met derden, tenzij nodig voor onze
          dienstverlening, wettelijk verplicht, of met expliciete toestemming.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="font-semibold">7. Cookies</h2>
        <p className="text-neutral-700">
          We gebruiken vooral noodzakelijke en analytische cookies. Zie ook onze
          <a className="underline" href="/cookies"> cookieverklaring</a>.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="font-semibold">8. Jouw rechten (AVG)</h2>
        <ul className="list-disc pl-5 text-neutral-700">
          <li>Recht op inzage, rectificatie, beperking en verwijdering.</li>
          <li>Recht op dataportabiliteit en bezwaar.</li>
          <li>Je kunt een verzoek indienen zodra onze contactmail actief is.</li>
        </ul>
      </section>

      <section className="space-y-2">
        <h2 className="font-semibold">9. Beveiliging</h2>
        <p className="text-neutral-700">
          We nemen passende technische en organisatorische maatregelen om misbruik,
          verlies, onbevoegde toegang en ongewenste openbaarmaking te voorkomen.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="font-semibold">10. Wijzigingen</h2>
        <p className="text-neutral-700">
          We kunnen deze verklaring wijzigen. De meest actuele versie staat altijd op <em>/privacy</em>.
        </p>
      </section>
    </div>
  );
}
