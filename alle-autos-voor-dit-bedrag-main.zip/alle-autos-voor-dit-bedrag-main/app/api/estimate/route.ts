// app/api/estimate/route.ts
import { NextResponse } from "next/server";

/**
 * Simple estimator using RDW Open Data (catalogusprijs + first registration -> age)
 *
 * Usage:
 *  - /api/estimate?kenteken=11DD11
 *  - /api/estimate?merk=Volkswagen&model=Golf&year=2012
 *
 * Notes:
 *  - RDW Socrata base: https://opendata.rdw.nl/resource/m9d7-ebf2.json
 *  - This is a heuristic POC — replace heuristics with real price data later.
 */

const RDW_BASE = "https://opendata.rdw.nl/resource/m9d7-ebf2.json";

// simple helper to fetch RDW by kenteken (license plate)
async function fetchByKenteken(kenteken: string) {
  const q = `${RDW_BASE}?$where=UPPER(kenteken)='${kenteken.toUpperCase()}'&$limit=1`;
  const res = await fetch(q);
  if (!res.ok) throw new Error(`RDW fetch failed: ${res.status}`);
  const data = await res.json();
  return data[0] || null;
}

// very naive search by merk/model/year — returns first match
async function fetchByMerkModelYear(merk: string, model: string, year?: string) {
  // Build a where clause that matches brand and model (case-insensitive). Tweak as needed.
  let where = `UPPER(merk)='${merk.toUpperCase()}' AND UPPER(handelsbenaming) LIKE '%${model.toUpperCase()}%'`;
  if (year) {
    // RDW field for first registration date: 'datum_eerste_toelating' or 'datum_eerste_toelating_nl'
    // We'll filter by year matching the date string.
    where += ` AND datum_eerste_toelating LIKE '${year}%'`;
  }
  const q = `${RDW_BASE}?$where=${encodeURIComponent(where)}&$limit=1`;
  const res = await fetch(q);
  if (!res.ok) throw new Error(`RDW fetch failed: ${res.status}`);
  const data = await res.json();
  return data[0] || null;
}

// Helper: parse catalogusprijs field robustly
function parseCatalogus(value: any): number | null {
  if (value == null) return null;
  const n = Number(String(value).replace(/[^\d]/g, ""));
  return Number.isFinite(n) && n > 0 ? n : null;
}

// Estimate function (simple, tweakable)
function estimateFromCatalog(catalogus: number | null, firstRegistrationDate: string | null) {
  const now = new Date();
  let age = 0;
  if (firstRegistrationDate) {
    const y = Number(firstRegistrationDate.slice(0, 4));
    if (!Number.isNaN(y)) age = Math.max(0, now.getFullYear() - y);
  }

  // Heuristic parameters (tweak as you like)
  const depr_first = 0.20; // 20% first year
  const depr_annual = 0.07; // 7% per following year
  const floor = 0.03; // don't go below 3% of catalogus

  if (catalogus == null) {
    // fallback: return null and give guidance
    return { estimated: null, age };
  }

  // compute multiplier
  const yearsAfterFirst = Math.max(0, age - 1);
  let multiplier = 1 - depr_first - depr_annual * yearsAfterFirst;
  multiplier = Math.max(multiplier, floor);

  const estimated = Math.round(catalogus * multiplier);

  return { estimated, age, multiplier };
}

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const kenteken = url.searchParams.get("kenteken");
    const merk = url.searchParams.get("merk");
    const model = url.searchParams.get("model");
    const year = url.searchParams.get("year");

    let record: any = null;

    if (kenteken) {
      record = await fetchByKenteken(kenteken);
    } else if (merk && model) {
      record = await fetchByMerkModelYear(merk, model, year || undefined);
    } else {
      return NextResponse.json({ error: "Provide kenteken OR merk+model (optionally year)" }, { status: 400 });
    }

    if (!record) {
      return NextResponse.json({ error: "No RDW record found" }, { status: 404 });
    }

    // Try various field names for catalogusprijs and first registration
    const catalogRaw = record.catalogusprijs ?? record.catalogus_waarde ?? record.cataloguswaarde ?? record.catalogus_prijs;
    const catalogus = parseCatalogus(catalogRaw);

    // RDW commonly has field 'datum_eerste_toelating' or 'datum_eerste_toelating_dt'
    const firstReg = record.datum_eerste_toelating ?? record.datum_eerste_toelating_dt ?? null;

    const est = estimateFromCatalog(catalogus, firstReg ?? null);

    return NextResponse.json({
      meta: {
        source: "RDW (opendata.rdw.nl resource m9d7-ebf2)",
        found: true,
      },
      input: {
        kenteken: record.kenteken ?? null,
        merk: record.merk ?? record.handelsbenaming ?? null,
        model: record.handelsbenaming ?? null,
        catalogus_raw: catalogRaw ?? null,
        catalogus: catalogus,
        datum_eerste_toelating: firstReg ?? null,
      },
      estimate: {
        estimated_price: est.estimated,
        age: est.age,
        multiplier: est.multiplier ?? null,
        note: est.estimated == null ? "No catalogusprijs available — need model-based defaults or market data" : "Estimate = catalogusprijs * multiplier (see multiplier)",
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: "Server error", detail: String(err?.message ?? err) }, { status: 500 });
  }
}
