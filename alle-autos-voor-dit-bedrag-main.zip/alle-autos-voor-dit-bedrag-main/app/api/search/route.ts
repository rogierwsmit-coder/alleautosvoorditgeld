import { NextResponse } from "next/server";
import { hasKV, kv, keyForPrice } from "@/lib/kv";
import { demoCars } from "@/lib/demoData";

export async function POST(req: Request) {
  try {
    const { amount } = await req.json();
    const parsed = parseInt(String(amount), 10);
    if (!Number.isFinite(parsed) || parsed <= 0) {
      return NextResponse.json({ error: "Ongeldig bedrag" }, { status: 400 });
    }

    let cars = [] as any[];

    if (hasKV) {
      try {
        const fromKV = await kv.get<any[]>(keyForPrice(parsed));
        if (fromKV && Array.isArray(fromKV)) {
          cars = fromKV;
        }
      } catch (e) {
        // ignore, fallback to demo
      }
    }

    if (cars.length === 0) {
      cars = demoCars.filter((c) => c.price === parsed);
    }

    return NextResponse.json({ cars });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Serverfout" }, { status: 500 });
  }
}
