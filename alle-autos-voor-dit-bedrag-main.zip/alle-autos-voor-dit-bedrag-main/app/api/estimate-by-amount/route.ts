import { NextResponse } from "next/server";

const RDW_BASE = "https://opendata.rdw.nl/resource/m9d7-ebf2.json";

function parseCatalogus(v: any): number | null {
  if (v == null) return null;
  const n = Number(String(v).replace(/[^\d]/g, ""));
  return Number.isFinite(n) && n > 0 ? n : null;
}

function estimate(catalogus: number | null, year: number | null) {
  if (!catalogus || !year) return { estimated: null, age: null, multiplier: null };
  const nowY = new Date().getFullYear();
  const age = Math.max(0, nowY - year);

  const depr_first = 0.20;
  const depr_annual = 0.07;
  const floor = 0.03;

  const yearsAfterFirst = Math.max(0, age - 1);
  let mult = 1 - depr_first - depr_annual * yearsAfterFirst;
  mult = Math.max(mult, floor);

  return { estimated: Math.round(catalogus * mult), age, multiplier: mult };
}

// Kandidatenlijst (optie A)
const CANDIDATES: Array<{ merk: string; model: string; years: number[] }> = [
  { merk: "Volkswagen", model: "Golf", years: [2008, 2010, 2012, 2014, 2016, 2018] },
  { merk: "Volkswagen", model: "Polo", years: [2008, 2010, 2012, 2014, 2016, 2018] },
  { merk: "BMW", model: "3", years: [2008, 2010, 2012, 2014, 2016, 2018] },
  { merk: "Opel", model: "Astra", years: [2008, 2010, 2012, 2014, 2016, 2018] },
  { merk: "Ford", model: "Focus", years: [2008, 2010, 2012, 2014, 2016, 2018] },
  { merk: "Toyota", model: "Yaris", years: [2008, 2010, 2012, 2014, 2016, 2018] },
  { merk: "Renault", model: "Clio", years: [2008, 2010, 2012, 2014, 2016, 2018] },
  { merk: "Peugeot", model: "208", years: [2012, 2014, 2016, 2018] },
  { merk: "Audi", model: "A3", years: [2008, 2010, 2012, 2014, 2016, 2018] }
];

async function fetchCandidate(c: { merk: string; model: string; years: number[] }) {
  const results: any[] = [];
  for (const y of c.years) {
    const where = `UPPER(merk)='${c.merk.toUpperCase()}' AND UPPER(handelsbenaming) LIKE '%${c.model.toUpperCase()}%' AND datum_eerste_toelating LIKE '${y}%'`;
    const url = `${RDW_BASE}?$where=${encodeURIComponent(where)}&$limit=1`;
    const r = await fetch(url, { next: { revalidate: 86400 } });
    if (!r.ok) continue;
    const arr = await r.json();
    const rec = arr?.[0];
    if (!rec) continue;

    const catalogus = parseCatalogus(rec.catalogusprijs);
    const year = Number(String(rec.datum_eerste_toelating || "").slice(0, 4)) || y;
    const est = estimate(catalogus, year);
    if (!est.estimated) continue;

    results.push({
      merk: rec.merk,
      model: rec.handelsbenaming,
      year,
      catalogus,
      estimated_price: est.estimated,
      age: est.age,
      rdw_kenteken: rec.kenteken,
      source: "candidate"
    });
  }
  return results;
}

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const amountStr = searchParams.get("amount");
    if (!amountStr) {
      return NextResponse.json({ error: "Missing amount" }, { status: 400 });
    }
    const amount = Number(String(amountStr).replace(/[^\d]/g, ""));
    if (!Number.isFinite(amount) || amount <= 0) {
      return NextResponse.json({ error: "Invalid amount" }, { status: 400 });
    }

    // Optie A
    const candidateTasks = CANDIDATES.map((c) => fetchCandidate(c));
    const candidateResults = (await Promise.all(candidateTasks)).flat();

    // Optie B
    const url = `${RDW_BASE}?$limit=2000&$select=kenteken,merk,handelsbenaming,catalogusprijs,datum_eerste_toelating`;
    const resp = await fetch(url, { next: { revalidate: 3600 } });
    const bulk = resp.ok ? ((await resp.json()) as any[]) : [];

    const bulkResults = bulk
      .map((rec) => {
        const catalogus = parseCatalogus(rec.catalogusprijs);
        const year = rec.datum_eerste_toelating
          ? Number(String(rec.datum_eerste_toelating).slice(0, 4))
          : null;
        const est = estimate(catalogus, year);
        if (!est.estimated) return null;
        return {
          merk: rec.merk,
          model: rec.handelsbenaming,
          year,
          catalogus,
          estimated_price: est.estimated,
          age: est.age,
          rdw_kenteken: rec.kenteken,
          source: "bulk"
        };
      })
      .filter(Boolean) as any[];

    // Combineer en pak nu 50 resultaten
    const all = [...candidateResults, ...bulkResults];
    const ranked = all
      .sort((a, b) => Math.abs(a.estimated_price - amount) - Math.abs(b.estimated_price - amount))
      .slice(0, 50);

    return NextResponse.json({
      meta: {
        target_amount: amount,
        candidates_checked: all.length,
        returned: ranked.length,
        note: "POC: mix van populaire modellen (option A) + bulk steekproef (option B)."
      },
      data: ranked
    });
  } catch (e: any) {
    return NextResponse.json({ error: "Server error", detail: String(e?.message || e) }, { status: 500 });
  }
}
