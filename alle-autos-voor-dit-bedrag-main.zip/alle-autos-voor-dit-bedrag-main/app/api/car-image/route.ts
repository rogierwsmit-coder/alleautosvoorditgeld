import { NextResponse } from "next/server";

/**
 * Slimme auto-afbeelding proxy met alleen open bronnen:
 * 1) Wikidata (P18)  2) Wikimedia Commons (file search)  3) Wikipedia multi-lang (scoring)
 * → Als niets goed genoeg is, een nette SVG.
 *
 * Response header: X-Image-Source met bron + korte toelichting.
 */

/* -------------------- helpers -------------------- */

const OLD_DECADES = ["1900s","1910s","1920s","1930s","1940s","1950s","1960s","1970s","1980s","1990s"];
const MODERN_DECADES = ["2000s","2010s","2020s","2030s"];

function tidy(s: string) { return s.replace(/\s+/g, " ").trim(); }

function normalizeModel(brand: string, rawModel: string) {
  let model = tidy(rawModel)
    .replace(new RegExp(`^${brand}\\s+`, "i"), "")
    .replace(/\bserie\b/i, "Series");

  // Enkele veelvoorkomende normalisaties
  if (/3er\s*reihe/i.test(model)) return "3 Series";
  if (/5er\s*reihe/i.test(model)) return "5 Series";
  if (/1er\s*reihe/i.test(model)) return "1 Series";
  if (/7er\s*reihe/i.test(model)) return "7 Series";

  if (/^a\s*\d{2,3}$/i.test(model) || /^a-klasse$/i.test(model)) return "A-Class";
  if (/^b\s*\d{2,3}$/i.test(model) || /^b-klasse$/i.test(model)) return "B-Class";
  if (/^c\s*\d{2,3}$/i.test(model) || /^c-klasse$/i.test(model)) return "C-Class";
  if (/^e\s*\d{2,3}$/i.test(model) || /^e-klasse$/i.test(model)) return "E-Class";
  if (/^s\s*\d{2,3}$/i.test(model) || /^s-klasse$/i.test(model)) return "S-Class";

  // generieke rommel weghalen
  model = model.replace(/\b(4dr|5dr|door|hybrid|diesel|petrol|benzine)\b/gi, "");
  return tidy(model);
}

function yearToDecadeStr(year: number): string | null {
  if (!year || isNaN(year)) return null;
  const d = Math.floor(year / 10) * 10;
  return `${d}s`;
}

async function fetchBytes(url: string, revalidateSeconds = 86400) {
  const r = await fetch(url, { redirect: "follow", next: { revalidate: revalidateSeconds } });
  if (!r.ok) throw new Error(`Upstream ${r.status}`);
  const type = r.headers.get("content-type") || "image/jpeg";
  const buf = await r.arrayBuffer();
  return { buf, type };
}

/* -------------------- 1) Wikidata P18 -------------------- */

type WikidataSearchHit = { id: string; label?: string; description?: string; };

async function wikidataSearch(query: string): Promise<WikidataSearchHit[]> {
  const url = `https://www.wikidata.org/w/api.php?action=wbsearchentities&search=${encodeURIComponent(query)}&language=en&type=item&format=json&origin=*&limit=6`;
  const res = await fetch(url, { next: { revalidate: 86400 } });
  if (!res.ok) return [];
  const json = await res.json();
  return (json?.search || []) as WikidataSearchHit[];
}

type WikidataEntity = {
  id: string;
  labels?: Record<string, { value: string }>;
  descriptions?: Record<string, { value: string }>;
  claims?: Record<string, any[]>;
};

async function wikidataGetEntities(ids: string[]): Promise<Record<string, WikidataEntity>> {
  const url = `https://www.wikidata.org/w/api.php?action=wbgetentities&ids=${ids.join("|")}&format=json&origin=*&props=labels|descriptions|claims`;
  const res = await fetch(url, { next: { revalidate: 86400 } });
  if (!res.ok) return {};
  const json = await res.json();
  return json?.entities || {};
}

function extractP18File(entity: WikidataEntity): string | null {
  const p18 = entity?.claims?.["P18"];
  if (!Array.isArray(p18) || !p18.length) return null;
  const mainsnak = p18[0]?.mainsnak;
  const datavalue = mainsnak?.datavalue;
  const fileName = datavalue?.value;
  if (!fileName || typeof fileName !== "string") return null;
  return fileName; // bestandsnaam op Commons
}

// Zet een Commons-bestandsnaam om naar directe file-path URL (lossless)
function commonsFilePath(fileName: string) {
  // Special:FilePath zorgt voor nette redirect naar origin met juiste encodering
  return `https://commons.wikimedia.org/wiki/Special:FilePath/${encodeURIComponent(fileName)}?width=1200`;
}

function looksLikeMotorcycle(desc: string | undefined) {
  if (!desc) return false;
  const s = desc.toLowerCase();
  return s.includes("motorcycle") || s.includes("motorbike") || s.includes("bike");
}

async function tryWikidataP18(brand: string, model: string, year: number) {
  const q1 = `${brand} ${model} ${isNaN(year) ? "" : year + " " }car`;
  const q2 = `${brand} ${model}`;

  for (const q of [q1, q2]) {
    const hits = await wikidataSearch(q);
    if (!hits.length) continue;

    // Haal details op
    const ids = hits.map(h => h.id);
    const entities = await wikidataGetEntities(ids);

    // Kies beste: voorkom motorfiets, kies item met P18
    for (const h of hits) {
      const e = entities[h.id];
      if (!e) continue;

      // description check
      const desc = e.descriptions?.en?.value || e.descriptions?.nl?.value || h.description || "";
      if (looksLikeMotorcycle(desc)) continue;

      const p18 = extractP18File(e);
      if (p18) {
        const url = commonsFilePath(p18);
        return { src: url, meta: `wikidata:${h.id} (${q})` };
      }
    }
  }
  return null;
}

/* -------------------- 2) Commons file search -------------------- */

type CommonsFilePage = { title: string; imageinfo?: { url: string }[] };

async function commonsFileSearch(query: string) {
  // Zoek in bestandsnaam (namespace 6), geef imageinfo.url terug
  const url =
    `https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*` +
    `&generator=search&gsrsearch=${encodeURIComponent(query)}` +
    `&gsrlimit=10&gsrnamespace=6&prop=imageinfo&iiprop=url&iiurlwidth=1200`;
  const res = await fetch(url, { next: { revalidate: 86400 } });
  if (!res.ok) return [];
  const json = await res.json();
  const pages = json?.query?.pages;
  if (!pages) return [];
  return Object.values(pages) as CommonsFilePage[];
}

function scoreCommonsFile(brand: string, model: string, year: number, title: string): number {
  const t = title.toLowerCase();
  let score = 0;
  if (t.includes(brand.toLowerCase())) score += 2;

  // model tokens
  const mtoks = model.toLowerCase().split(/\s+/).filter(Boolean);
  let hits = 0;
  mtoks.forEach(tok => { if (t.includes(tok)) hits++; });
  score += Math.min(hits, 2);

  // jaartal hints in bestandsnaam helpen soms
  if (!isNaN(year) && t.includes(String(year))) score += 1;

  // Straf ongewenste woorden
  if (/(motorcycle|motorbike|bike|truck|bus|lorry)/i.test(title)) score -= 3;

  return score;
}

async function tryCommons(brand: string, model: string, year: number) {
  const q1 = `${brand} ${model} ${isNaN(year) ? "" : year + " " }car`;
  const q2 = `${brand} ${model} car`;
  const q3 = `${brand} ${model}`;

  for (const q of [q1, q2, q3]) {
    const files = await commonsFileSearch(q);
    if (!files.length) continue;

    // Scoreer en kies de beste
    let best: { url: string; title: string; score: number } | null = null;
    for (const f of files) {
      const url = f.imageinfo?.[0]?.url;
      if (!url) continue;
      const s = scoreCommonsFile(brand, model, year, f.title);
      if (!best || s > best.score) best = { url, title: f.title, score: s };
    }

    if (best && best.score >= 1) {
      return { src: best.url, meta: `commons (${q}) [${best.title}] score=${best.score}` };
    }
  }
  return null;
}

/* -------------------- 3) Wikipedia multi-lang met scoring (fallback) -------------------- */

type WikiPage = {
  pageid: number;
  title: string;
  original?: { source: string; width: number; height: number };
  categories?: { title: string }[];
};

async function wikiSearch(lang: string, query: string): Promise<WikiPage[]> {
  const url =
    `https://${lang}.wikipedia.org/w/api.php` +
    `?action=query&format=json&origin=*` +
    `&prop=pageimages|categories&piprop=original&cllimit=50` +
    `&generator=search&gsrsearch=${encodeURIComponent(query)}&gsrlimit=5`;
  const res = await fetch(url, { next: { revalidate: 86400 } });
  if (!res.ok) return [];
  const json = await res.json();
  const pages = json?.query?.pages;
  if (!pages) return [];
  return Object.values(pages) as WikiPage[];
}

function scoreWikipediaCandidate(opts: {
  brand: string; model: string; year: number;
  title: string; categories: string[];
}): number {
  const { brand, model, year, title, categories } = opts;
  const t = title.toLowerCase();

  let score = 0;

  if (t.includes(brand.toLowerCase())) score += 2;

  const modelTokens = model.toLowerCase().split(/\s+/).filter(Boolean);
  let modelHit = 0;
  modelTokens.forEach(tok => { if (t.includes(tok)) modelHit++; });
  score += Math.min(modelHit, 2);

  const decade = yearToDecadeStr(year);
  const catsLC = categories.map(c => c.toLowerCase());
  if (decade) {
    const hasModern = catsLC.some(c =>
      c.includes(decade.toLowerCase()) || MODERN_DECADES.some(d => c.includes(d.toLowerCase()))
    );
    if (hasModern) score += 3;

    const hasOld = catsLC.some(c => OLD_DECADES.some(d => c.includes(d.toLowerCase())));
    if (hasOld) score -= 3;
  }

  if (/\bclass\b/i.test(title) || /\bseries\b/i.test(title) || /\bW\d{3}\b/i.test(title)) score += 1;

  // Straf expliciete bus/truck/motor
  if (/(motorcycle|truck|bus|lorry)/i.test(title)) score -= 3;

  return score;
}

async function tryWikipedia(brand: string, model: string, year: number) {
  const langs = ["en", "nl", "de", "fr", "it", "es"];
  const queries = [
    `${brand} ${model} ${isNaN(year) ? "" : year + " " }car`,
    `${brand} ${model} car`,
    `${brand} ${model}`,
  ];

  for (const lang of langs) {
    for (const q of queries) {
      const pages = await wikiSearch(lang, q);
      if (!pages.length) continue;

      let best: { p: WikiPage; score: number } | null = null;
      for (const p of pages) {
        if (!p.original?.source) continue;
        const cats = (p.categories || []).map(c => c.title.replace(/^Category:/i, ""));
        const s = scoreWikipediaCandidate({
          brand, model, year,
          title: p.title,
          categories: cats,
        });
        if (!best || s > best.score) best = { p, score: s };
      }
      if (best && best.score >= 1) {
        return { src: best.p.original!.source, meta: `wikipedia:${lang} (${q}) [${best.p.title}] score=${best.score}` };
      }
    }
  }
  return null;
}

/* -------------------- handler -------------------- */

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const qRaw = searchParams.get("q") || "car";  // "Mercedes-Benz,E 220 d,2019,car"
  const tokens = qRaw.split(",").map(t => t.trim()).filter(Boolean);

  const brand = tokens[0] || "";
  const rawModel = tokens[1] || "";
  const year = Number(tokens[2]) || NaN;

  const model = normalizeModel(brand, rawModel);

  // 1) Wikidata (P18)
  if (brand && model) {
    const w = await tryWikidataP18(brand, model, year);
    if (w?.src) {
      try {
        const { buf, type } = await fetchBytes(w.src, 86400);
        return new NextResponse(buf, {
          status: 200,
          headers: {
            "Content-Type": type,
            "Cache-Control": "public, s-maxage=86400, max-age=3600, stale-while-revalidate=604800",
            "X-Image-Source": `wikidata (${w.meta})`,
          },
        });
      } catch { /* ga door */ }
    }
  }

  // 2) Commons files (beste titelmatch)
  if (brand && model) {
    const c = await tryCommons(brand, model, year);
    if (c?.src) {
      try {
        const { buf, type } = await fetchBytes(c.src, 86400);
        return new NextResponse(buf, {
          status: 200,
          headers: {
            "Content-Type": type,
            "Cache-Control": "public, s-maxage=86400, max-age=3600, stale-while-revalidate=604800",
            "X-Image-Source": c.meta,
          },
        });
      } catch { /* ga door */ }
    }
  }

  // 3) Wikipedia multi-lang (scoring)
  if (brand && model) {
    const hit = await tryWikipedia(brand, model, year);
    if (hit?.src) {
      try {
        const { buf, type } = await fetchBytes(hit.src, 86400);
        return new NextResponse(buf, {
          status: 200,
          headers: {
            "Content-Type": type,
            "Cache-Control": "public, s-maxage=86400, max-age=3600, stale-while-revalidate=604800",
            "X-Image-Source": hit.meta,
          },
        });
      } catch { /* ga door */ }
    }
  }

  // 4) Ultime fallback: nette SVG
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="480" height="320">
      <rect width="100%" height="100%" fill="#f3f4f6"/>
      <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle"
            font-family="system-ui, sans-serif" font-size="14" fill="#9ca3af">
        geen afbeelding
      </text>
    </svg>
  `.trim();

  return new NextResponse(svg, {
    status: 200,
    headers: {
      "Content-Type": "image/svg+xml",
      "Cache-Control": "public, s-maxage=3600, max-age=600, stale-while-revalidate=604800",
      "X-Image-Source": "svg",
    },
  });
}
