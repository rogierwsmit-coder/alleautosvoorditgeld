import { NextResponse } from "next/server";
import { hasKV, kv, keyForPrice } from "@/lib/kv";

export const runtime = "nodejs";

function parseCSV(text: string) {
  const lines = text.split(/\r?\n/).filter(Boolean);
  if (lines.length === 0) return [];
  const header = lines[0].split(",").map((h) => h.trim().toLowerCase());
  const rows = lines.slice(1).map((line) => {
    const cols = line.split(","); // naive CSV parse (no quotes)
    const obj: any = {};
    header.forEach((h, i) => (obj[h] = (cols[i] || "").trim()));
    return obj;
  });
  return rows;
}

export async function POST(req: Request) {
  if (!hasKV) {
    return NextResponse.json(
      { error: "KV niet geconfigureerd; upload is uitgeschakeld" },
      { status: 400 }
    );
  }

  const form = await (req as any).formData?.();
  const file = form?.get("file") as File | null;
  if (!file) {
    return NextResponse.json({ error: "Geen bestand ontvangen" }, { status: 400 });
  }

  const text = await file.text();
  const rows = parseCSV(text);

  // Expect columns: price, title, url, image, mileageKm, year, source, id
  const byPrice: Record<string, any[]> = {};
  for (const r of rows) {
    const price = parseInt(String(r.price || r.prijs || r.amount), 10);
    if (!Number.isFinite(price)) continue;
    const car = {
      id: String(r.id || `${r.source || "feed"}-${price}-${Math.random().toString(36).slice(2,8)}`),
      title: String(r.title || r.titel || "Onbekende auto"),
      price,
      year: r.year ? parseInt(String(r.year), 10) : undefined,
      mileageKm: r.mileageKm ? parseInt(String(r.mileageKm), 10) : undefined,
      image: r.image || undefined,
      url: r.url || undefined,
      source: r.source || "Feed",
    };
    const key = String(price);
    byPrice[key] ||= [];
    byPrice[key].push(car);
  }

  for (const [price, cars] of Object.entries(byPrice)) {
    await kv.set(keyForPrice(parseInt(price, 10)), cars);
  }

  return NextResponse.json({ storedPrices: Object.keys(byPrice) });
}
