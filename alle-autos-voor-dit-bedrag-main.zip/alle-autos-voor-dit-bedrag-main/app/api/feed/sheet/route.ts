import { NextResponse } from "next/server";
import { hasKV, kv, keyForPrice } from "@/lib/kv";

export const runtime = "nodejs";

function parseCSV(text: string) {
  const lines = text.split(/\r?\n/).filter(Boolean);
  if (lines.length === 0) return [];
  const header = lines[0].split(",").map((h) => h.trim().toLowerCase());
  const rows = lines.slice(1).map((line) => {
    const cols = line.split(","); // naive CSV parse (no quotes)
    const obj: any = {};
    header.forEach((h, i) => (obj[h] = (cols[i] || "").trim()));
    return obj;
  });
  return rows;
}

export async function POST(req: Request) {
  if (!hasKV) {
    return NextResponse.json(
      { error: "KV niet geconfigureerd; sheet import is uitgeschakeld" },
      { status: 400 }
    );
  }

  const { csvUrl } = await req.json();
  if (!csvUrl || typeof csvUrl !== "string") {
    return NextResponse.json({ error: "csvUrl ontbreekt" }, { status: 400 });
  }

  const res = await fetch(csvUrl);
  if (!res.ok) {
    return NextResponse.json({ error: "Kon CSV niet ophalen" }, { status: 400 });
  }
  const text = await res.text();
  const rows = parseCSV(text);

  const byPrice: Record<string, any[]> = {};
  for (const r of rows) {
    const price = parseInt(String(r.price || r.prijs || r.amount), 10);
    if (!Number.isFinite(price)) continue;
    const car = {
      id: String(r.id || `${r.source || "sheet"}-${price}-${Math.random().toString(36).slice(2,8)}`),
      title: String(r.title || r.titel || "Onbekende auto"),
      price,
      year: r.year ? parseInt(String(r.year), 10) : undefined,
      mileageKm: r.mileageKm ? parseInt(String(r.mileageKm), 10) : undefined,
      image: r.image || undefined,
      url: r.url || undefined,
      source: r.source || "Sheet",
    };
    const key = String(price);
    byPrice[key] ||= [];
    byPrice[key].push(car);
  }

  for (const [price, cars] of Object.entries(byPrice)) {
    await kv.set(keyForPrice(parseInt(price, 10)), cars);
  }

  return NextResponse.json({ storedPrices: Object.keys(byPrice) });
}
