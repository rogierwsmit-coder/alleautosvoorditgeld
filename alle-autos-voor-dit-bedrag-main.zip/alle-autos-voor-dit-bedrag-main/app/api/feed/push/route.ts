import { NextResponse } from "next/server";
import { hasKV, kv, keyForPrice } from "@/lib/kv";

export async function POST(req: Request) {
  if (!hasKV) {
    return NextResponse.json(
      { error: "KV niet geconfigureerd; push is uitgeschakeld" },
      { status: 400 }
    );
  }

  const { cars } = await req.json();
  if (!Array.isArray(cars)) {
    return NextResponse.json({ error: "cars moet een array zijn" }, { status: 400 });
  }

  const byPrice: Record<string, any[]> = {};
  for (const r of cars) {
    const price = parseInt(String(r.price), 10);
    if (!Number.isFinite(price)) continue;
    const car = {
      id: String(r.id || `push-${price}-${Math.random().toString(36).slice(2,8)}`),
      title: String(r.title || "Onbekende auto"),
      price,
      year: r.year ? parseInt(String(r.year), 10) : undefined,
      mileageKm: r.mileageKm ? parseInt(String(r.mileageKm), 10) : undefined,
      image: r.image || undefined,
      url: r.url || undefined,
      source: r.source || "Push",
    };
    const key = String(price);
    byPrice[key] ||= [];
    byPrice[key].push(car);
  }

  for (const [price, carsArr] of Object.entries(byPrice)) {
    await kv.set(keyForPrice(parseInt(price, 10)), carsArr);
  }

  return NextResponse.json({ storedPrices: Object.keys(byPrice) });
}
