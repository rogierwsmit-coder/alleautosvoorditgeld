import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Algemene voorwaarden",
  description:
    "Voorwaarden voor het gebruik van de website Alle auto’s voor dit geld.",
};

export default function TermsPage() {
  return (
    <div className="mx-auto max-w-3xl p-6 prose prose-neutral">
      <h1>Algemene voorwaarden van gebruik</h1>
      <p><strong>Laatst bijgewerkt:</strong> 22 augustus 2025</p>

      <h2>1. Toepasselijkheid</h2>
      <p>
        Deze algemene voorwaarden zijn van toepassing op ieder bezoek aan en gebruik van de website
        <em> alleautosvoorditgeld.nl</em> (“Website”) en op alle daarmee samenhangende diensten
        die via de Website worden aangeboden (“Diensten”). Door de Website te gebruiken ga je akkoord
        met deze voorwaarden.
      </p>

      <h2>2. Definities</h2>
      <p>
        “Bezoeker”: iedere natuurlijke of rechtspersoon die de Website bezoekt of gebruikt. <br/>
        “Aanbieder”: partij die voertuiginformatie (bijv. via CSV/Feed) aanlevert voor publicatie. <br/>
        “Content”: alle gegevens, teksten, afbeeldingen, links en overige informatie op de Website.
      </p>

      <h2>3. Doel en aard van de Website</h2>
      <p>
        De Website toont voertuigen die voor een <strong>exact</strong> ingevoerd bedrag worden aangeboden.
        De Website is een <strong>aggregatie-/publicatieplatform</strong> en geen verkoper, bemiddelaar
        of veilingplatform. Wij zijn niet partij bij eventuele overeenkomsten tussen Bezoekers en Aanbieders.
      </p>

      <h2>4. Gebruik van de Website</h2>
      <ul>
        <li>Je gebruikt de Website uitsluitend voor rechtmatige doeleinden.</li>
        <li>Het is niet toegestaan de Website te verstoren, te overbelasten, te scrapen of te reverse-engineren.</li>
        <li>Automatische toegang (bots/scripts) is alleen toegestaan met onze schriftelijke toestemming.</li>
      </ul>

      <h2>5. Informatie, prijzen en beschikbaarheid</h2>
      <ul>
        <li>
          Prijzen, specificaties en beschikbaarheid van voertuigen worden (deels) aangeleverd door Aanbieders
          of externe bronnen. We streven naar actuele en juiste informatie, maar kunnen <strong>geen garantie</strong>
          geven dat alle Content volledig, juist of actueel is.
        </li>
        <li>
          We behouden ons het recht voor Content te corrigeren, te verwijderen of de Website (tijdelijk) niet
          beschikbaar te stellen.
        </li>
        <li>
          De getoonde voertuigen vormen <strong>geen juridisch bindend aanbod</strong>; neem voor aankoopbeslissingen
          altijd rechtstreeks contact op met de betreffende Aanbieder.
        </li>
      </ul>

      <h2>6. Accounts</h2>
      <p>
        Indien in de toekomst accounts worden aangeboden, kunnen aanvullende voorwaarden of beleid van toepassing zijn.
        We mogen accounts weigeren of beëindigen bij misbruik of schending van deze voorwaarden.
      </p>

      <h2>7. Uploads en feeds door Aanbieders</h2>
      <ul>
        <li>
          Aanbieders garanderen dat zij gerechtigd zijn de aangeleverde Content te publiceren en dat deze geen inbreuk
          maakt op rechten van derden (waaronder intellectuele eigendomsrechten en privacyrechten).
        </li>
        <li>
          Door Content aan te leveren, verstrekt de Aanbieder ons een niet-exclusieve, wereldwijde, kosteloze licentie
          om deze Content te hosten, weer te geven, te publiceren en te distribueren voor het doel van de Website.
        </li>
        <li>
          Persoonsgegevens in aangeleverde Content moeten beperkt zijn tot hetgeen noodzakelijk is en in lijn met
          toepasselijke privacywetgeving (AVG). Aanbieders zijn zelf verantwoordelijk voor rechtmatige aanlevering.
        </li>
      </ul>

      <h2>8. Intellectuele eigendomsrechten</h2>
      <p>
        Alle (intellectuele) eigendomsrechten op de Website, lay-out, logo’s, software en overige Content berusten bij
        ons of onze licentiegevers. Het is niet toegestaan onderdelen te kopiëren, te verspreiden of openbaar te maken
        zonder voorafgaande schriftelijke toestemming, tenzij een wettelijke uitzondering van toepassing is.
      </p>

      <h2>9. Aansprakelijkheid</h2>
      <ul>
        <li>
          Voor zover wettelijk toegestaan sluiten wij alle aansprakelijkheid uit voor schade die voortvloeit uit of
          samenhangt met het gebruik van de Website of de (on)beschikbaarheid daarvan.
        </li>
        <li>
          In geen geval zijn wij aansprakelijk voor indirecte schade, gevolgschade, gederfde winst, gemiste besparingen
          of schade door bedrijfsstagnatie.
        </li>
        <li>
          Niets in deze voorwaarden sluit aansprakelijkheid uit voor opzet of bewuste roekeloosheid aan onze zijde.
        </li>
      </ul>

      <h2>10. Privacy en cookies</h2>
      <p>
        Wij gaan zorgvuldig om met persoonsgegevens. Een afzonderlijk privacy- en cookiebeleid kan op de Website worden
        gepubliceerd. Door de Website te gebruiken ga je akkoord met het gebruik van noodzakelijke cookies en, indien
        van toepassing, met de daarin beschreven doeleinden.
      </p>

      <h2>11. Externe links</h2>
      <p>
        De Website kan links naar websites van derden bevatten. Wij hebben geen controle over die sites en zijn niet
        verantwoordelijk voor de inhoud of beschikbaarheid daarvan.
      </p>

      <h2>12. Wijzigingen</h2>
      <p>
        We mogen deze voorwaarden wijzigen. De meest actuele versie staat altijd op <em>/terms</em>. Bij ingrijpende
        wijzigingen zullen we Bezoekers waar mogelijk informeren.
      </p>

      <h2>13. Toepasselijk recht en forumkeuze</h2>
      <p>
        Op deze voorwaarden en het gebruik van de Website is Nederlands recht van toepassing. Geschillen worden voorgelegd
        aan de bevoegde rechter te Amsterdam, behoudens dwingendrechtelijke bepalingen.
      </p>

      <h2>14. Contact</h2>
      <p>
        Heb je vragen? Neem contact op via de <a href="/contact">contactpagina</a>.
      </p>

      <hr />
      <p className="text-xs text-neutral-500">
        Dit document is een algemene template en vormt geen juridisch advies. Laat je uiteindelijke versie juridisch
        toetsen voordat je commercieel live gaat.
      </p>
    </div>
  );
}
