export const dynamic = "force-dynamic";
export const revalidate = 0;

type Search = { key?: string };

export default function UploadPage({ searchParams }: { searchParams: Search }) {
  const ok = (searchParams?.key || "") === "wafb-12345";

  if (!ok) {
    return (
      <section className="mx-auto max-w-3xl px-4 py-16 text-center">
        <h1 className="mb-3 text-3xl font-bold">Toegang geweigerd</h1>
        <p className="mb-6 text-neutral-700">
          Je mist de juiste sleutel om deze pagina te openen.
        </p>
        <a
          href="/"
          className="inline-flex items-center justify-center rounded-xl bg-black px-5 py-3 text-white shadow-sm transition-transform duration-150 ease-out hover:scale-105 hover:bg-neutral-900 hover:shadow-lg hover:shadow-black/20 focus:outline-none focus:ring-2 focus:ring-yellow-400/50"
        >
          Terug naar home
        </a>
      </section>
    );
  }

  return (
    <section className="mx-auto max-w-3xl px-4 py-16 text-center">
      <h1 className="mb-2 text-3xl font-bold">Upload</h1>
      <p className="mb-8 text-neutral-700">
        De uploadfunctie is nog niet actief. Binnenkort kun je hier je bestanden toevoegen.
      </p>

      <div className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
        <label className="mb-2 block text-sm font-medium text-neutral-700">
          Kies bestand
        </label>
        <input
          type="file"
          disabled
          className="block w-full cursor-not-allowed rounded-xl border border-neutral-300 px-4 py-3 text-sm text-neutral-500 bg-neutral-100"
        />

        <div className="mt-6 flex items-center justify-center gap-3">
          <button
            type="button"
            disabled
            className="inline-flex cursor-not-allowed items-center justify-center rounded-xl bg-neutral-400 px-5 py-3 text-white shadow-sm"
          >
            Uploaden (binnenkort beschikbaar)
          </button>

          <a
            href="/"
            className="inline-flex items-center justify-center rounded-xl border border-neutral-300 bg-white px-5 py-3 text-neutral-800 shadow-sm hover:bg-neutral-50"
          >
            Annuleren
          </a>
        </div>
      </div>

      <p className="mt-4 text-sm text-neutral-500">
        De uploadfunctie wordt toegevoegd zodra de backend actief is.
      </p>
    </section>
  );
}
