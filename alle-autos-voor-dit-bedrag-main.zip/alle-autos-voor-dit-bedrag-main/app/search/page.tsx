export const dynamic = "force-dynamic";

export default function SearchPage() {
  return (
    <section className="mx-auto max-w-3xl px-4 py-16 text-center">
      <h1 className="mb-4 text-3xl font-bold">Under Construction</h1>
      <p className="mb-6 text-lg text-neutral-700">
        Hier komt binnenkort de zoekfunctionaliteit. We zijn er hard mee bezig!
      </p>
      <div className="flex justify-center">
        <img
          src="https://cdn-icons-png.flaticon.com/512/679/679922.png"
          alt="Bouw werkzaamheden"
          width={120}
          height={120}
          className="opacity-80"
        />
      </div>
    </section>
  );
}
