export default function Loading() {
  const items = Array.from({ length: 9 });

  return (
    <main className="mx-auto max-w-5xl p-6">
      {/* Pagina-titel skeleton */}
      <div className="mb-4 h-6 w-64 rounded bg-neutral-200 animate-pulse" />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((_, i) => (
          <div key={i} className="interactive-card p-3">
            <div className="h-48 w-full rounded-xl bg-neutral-200 animate-pulse" />
            <div className="px-1 pt-3 pb-2 space-y-2">
              <div className="h-4 w-3/4 rounded bg-neutral-200 animate-pulse" />
              <div className="flex gap-2">
                <div className="h-6 w-16 rounded-full bg-neutral-200 animate-pulse" />
                <div className="h-6 w-20 rounded-full bg-neutral-200 animate-pulse" />
                <div className="h-6 w-16 rounded-full bg-neutral-200 animate-pulse" />
              </div>
              <div className="h-5 w-24 rounded bg-neutral-200 animate-pulse" />
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
