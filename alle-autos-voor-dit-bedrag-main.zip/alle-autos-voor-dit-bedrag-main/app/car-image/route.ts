import { NextResponse } from "next/server";

/**
 * Proxy naar een afbeeldingsbron, met nette cache headers.
 * Gebruik:
 *   /api/car-image?q=volkswagen,golf,2016,car&sig=3
 */
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q") || "car";
  const sig = searchParams.get("sig") || "0";

  // Primair: Unsplash Source (zoekt op tags)
  const primary = `https://source.unsplash.com/480x320/?${encodeURIComponent(q)}&sig=${encodeURIComponent(
    sig
  )}`;

  // Fallback: loremflickr (tags ondersteund); laatste redmiddel: picsum (seed)
  const fallback1 = `https://loremflickr.com/480/320/${encodeURIComponent("car")}?lock=${encodeURIComponent(
    sig
  )}`;
  const fallback2 = `https://picsum.photos/seed/${encodeURIComponent(q + "-" + sig)}/480/320`;

  const urls = [primary, fallback1, fallback2];

  for (const url of urls) {
    try {
      const upstream = await fetch(url, {
        // Volg redirects en download de uiteindelijke bytes
        redirect: "follow",
        // Zéér belangrijk: cache upstream result server-side
        next: { revalidate: 60 * 60 * 24 }, // 24 uur
      });

      if (!upstream.ok) continue;

      // Content-Type van upstream doorgeven
      const contentType = upstream.headers.get("content-type") || "image/jpeg";
      const arrayBuffer = await upstream.arrayBuffer();

      return new NextResponse(arrayBuffer, {
        status: 200,
        headers: {
          "Content-Type": contentType,
          // Cache in Vercel edge + browser
          "Cache-Control": "public, s-maxage=86400, max-age=3600, stale-while-revalidate=604800",
        },
      });
    } catch {
      // probeer volgende url
      continue;
    }
  }

  // Alles faalde: 1x transparante SVG terug, zodat layout intact blijft
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="480" height="320">
      <rect width="100%" height="100%" fill="#f3f4f6"/>
      <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle"
            font-family="system-ui, sans-serif" font-size="14" fill="#9ca3af">
        geen afbeelding
      </text>
    </svg>
  `.trim();

  return new NextResponse(svg, {
    status: 200,
    headers: {
      "Content-Type": "image/svg+xml",
      "Cache-Control": "public, s-maxage=86400, max-age=3600, stale-while-revalidate=604800",
    },
  });
}
