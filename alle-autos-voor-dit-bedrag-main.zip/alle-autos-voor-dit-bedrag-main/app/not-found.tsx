import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto max-w-2xl p-10 text-center">
      <h1 className="text-2xl font-semibold">Pagina niet gevonden</h1>
      <p className="mt-2 text-neutral-600">We konden deze pagina niet vinden.</p>
      <Link href="/" className="btn-ghost tap mt-6 inline-block">
        Terug naar home
      </Link>
    </div>
  );
}
