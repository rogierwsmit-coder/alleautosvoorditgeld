import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Cookies",
  description: "Cookieverklaring van Alle auto’s voor dit geld.",
};

export default function CookiesPage() {
  return (
    <div className="mx-auto max-w-3xl p-6 space-y-6">
      <h1 className="text-2xl font-semibold">Cookieverklaring</h1>
      <p className="text-sm text-neutral-500">
        <strong>Laatst bijgewerkt:</strong> 22 augustus 2025
      </p>

      <section className="space-y-2">
        <h2 className="font-semibold">1. Wat zijn cookies?</h2>
        <p className="text-neutral-700">
          Cookies zijn kleine tekstbestanden die bij bezoek aan websites op je apparaat
          worden geplaatst. Ze helpen functies werken en geven inzicht in gebruik.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="font-semibold">2. Welke cookies gebruiken we?</h2>
        <ul className="list-disc pl-5 text-neutral-700">
          <li><strong>Noodzakelijke cookies</strong>: basisfunctionaliteit en beveiliging.</li>
          <li><strong>Analytische cookies</strong>: geaggregeerde statistiek (geen trackingprofielen).</li>
          <li><strong>Functionele cookies</strong>: onthouden van eenvoudige voorkeuren (indien toegepast).</li>
        </ul>
      </section>

      <section className="space-y-2">
        <h2 className="font-semibold">3. Beheer van cookies</h2>
        <p className="text-neutral-700">
          Je kunt cookies beheren via je browserinstellingen. Het uitschakelen van
          cookies kan invloed hebben op de werking van de Website.
        </p>
      </section>

      <section className="space-y-2">
        <h2 className="font-semibold">4. Wijzigingen</h2>
        <p className="text-neutral-700">
          Bij aanpassing van ons cookiegebruik werken we deze verklaring bij. De meest
          actuele versie staat op <em>/cookies</em>.
        </p>
      </section>
    </div>
  );
}
