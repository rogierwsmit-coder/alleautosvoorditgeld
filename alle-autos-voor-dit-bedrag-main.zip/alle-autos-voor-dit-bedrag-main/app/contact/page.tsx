export const dynamic = "force-dynamic";
export const revalidate = 0;

export default function ContactPage() {
  return (
    <section className="mx-auto max-w-3xl px-4 py-16 text-center">
      <h1 className="mb-3 text-3xl font-bold">Contact</h1>
      <p className="mb-6 text-neutral-700">
        Binnenkort kun je ons hier direct bereiken per e-mail.
      </p>
      <button
        disabled
        className="inline-flex cursor-not-allowed items-center justify-center rounded-xl bg-neutral-400 px-5 py-3 text-white shadow-sm"
      >
        Mail ons (binnenkort beschikbaar)
      </button>
    </section>
  );
}
