export default function robots() {
  return {
    rules: [{ userAgent: "*", allow: "/" }],
    sitemap: "https://alleautosvoorditgeld.nl/sitemap.xml",
    host: "https://alleautosvoorditgeld.nl",
  };
}
