import { kv as vercelKV } from "@vercel/kv";

export const hasKV =
  !!process.env.KV_REST_API_URL && !!process.env.KV_REST_API_TOKEN;

export const kv = vercelKV;

// Helpers to build keys
export const keyForPrice = (amount: number) => `cars:${amount}`;
