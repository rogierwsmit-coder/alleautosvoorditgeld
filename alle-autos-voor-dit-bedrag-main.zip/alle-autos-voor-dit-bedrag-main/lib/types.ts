export type Car = {
  id: string;
  title: string;
  price: number;
  year?: number;
  mileageKm?: number;
  image?: string;
  url?: string;
  source?: string;
};
