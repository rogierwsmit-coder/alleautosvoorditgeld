import { Car } from "./types";

export const demoCars: Car[] = [
  { id: "as24-10000-1", title: "Volkswagen Golf 1.4 TSI", price: 10000, year: 2013, mileageKm: 145000, image: "https://images.unsplash.com/photo-1483729558449-99ef09a8c325", url: "https://www.autoscout24.com/", source: "Demo" },
  { id: "mp-10000-2", title: "BMW 1-serie 116i", price: 10000, year: 2012, mileageKm: 168000, image: "https://images.unsplash.com/photo-1517677208171-0bc6725a3e60", url: "https://www.marktplaats.nl/", source: "Demo" },
  { id: "at-7500-1", title: "Toyota Aygo 1.0", price: 7500, year: 2016, mileageKm: 82000, image: "https://images.unsplash.com/photo-1619767886558-efdc259cde1a", url: "https://www.autotrack.nl/", source: "Demo" },
  { id: "gp-7500-2", title: "Ford Fiesta 1.25", price: 7500, year: 2014, mileageKm: 120000, image: "https://images.unsplash.com/photo-1493236281737-1c1f2a7b1f3c", url: "https://www.gaspedaal.nl/", source: "Demo" },
  { id: "as24-5000-1", title: "Peugeot 206 1.4", price: 5000, year: 2006, mileageKm: 180000, image: "https://images.unsplash.com/photo-1550353127-b0da3aeaa0ca", url: "https://www.autoscout24.com/", source: "Demo" },
  { id: "mp-5000-2", title: "Opel Corsa 1.2", price: 5000, year: 2007, mileageKm: 175000, image: "https://images.unsplash.com/photo-1520256862855-398228c41684", url: "https://www.marktplaats.nl/", source: "Demo" },
];
