# Alle auto's voor dit bedrag

**Slogan:** _Auto mag... voor elk bedrag!_

Zoek alle auto's die **precies** voor jouw ingevoerde bedrag te koop zijn.

## Stack
- Next.js (App Router) + TypeScript
- Tailwind CSS
- Framer Motion
- (Optioneel) Vercel KV voor data-opslag

## Scripts
```bash
npm install
npm run dev
npm run build
npm start
```

## API-routes
- `POST /api/search` — body: `{ amount: number|string }` → geeft auto's exact op dat bedrag terug (KV of demo-data).
- `POST /api/feed/upload` — **multipart/form-data** met `file` (CSV) → slaat auto's op per exact bedrag in KV.
- `POST /api/feed/sheet` — body: `{ csvUrl: string }` → haalt CSV op en slaat op in KV.
- `POST /api/feed/push` — body: `{ cars: Car[] }` → pusht direct auto's naar KV.

**CSV** verwacht ten minste kolommen: `price,title,url,image,mileageKm,year,source,id` (id optioneel).

## ENV
Maak `.env` aan (of stel in Vercel in) als je Vercel KV gebruikt:

```
KV_REST_API_URL=...
KV_REST_API_TOKEN=...
KV_URL=...
ENABLE_DATA_ADMIN=true
```

Zonder KV werkt de site in **demo/static** modus (voorbeelden: 5000, 7500, 10000).

## Deploy (browser-only)
1. Upload alle bestanden naar een nieuwe GitHub repo (main branch).
2. Ga naar Vercel → **Import Project** → selecteer repo (Framework: Next.js, Root: `/`).
3. (Optioneel) Voeg ENV vars toe voor KV → **Deploy**.
4. Voeg domeinen toe en zet DNS via Vercel.

---

© 2025 Alle auto's voor dit bedrag
