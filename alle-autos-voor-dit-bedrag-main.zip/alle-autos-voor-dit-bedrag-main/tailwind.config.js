/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          green: "#145A32",
          greenDark: "#0F3D2E",
          red: "#DC2626",
          metalLight: "#f0f0f0",
          metalDark: "#c8c8c8",
        },
      },
      borderRadius: { "2xl": "1rem" },
      boxShadow: { soft: "0 10px 25px rgba(0,0,0,0.08)" },
    },
  },
  plugins: [],
};
