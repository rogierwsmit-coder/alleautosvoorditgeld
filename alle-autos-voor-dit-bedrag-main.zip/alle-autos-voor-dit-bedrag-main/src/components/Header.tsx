"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

export default function Header() {
  const [open, setOpen] = useState(false);

  // Close on route change (basic: close when hash/URL changes)
  useEffect(() => {
    const onHash = () => setOpen(false);
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  // Prevent body scroll when menu open
  useEffect(() => {
    if (open) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
  }, [open]);

  const navItems = [
    { href: "/", label: "Home" },
    { href: "/voorwaarden", label: "Voorwaarden" },
    // Voeg je eigen routes hier toe:
    // { href: "/privacy", label: "Privacy" },
    // { href: "/contact", label: "Contact" },
    // Upload afschermen? /upload?key=... blijft gewoon werken:
    // { href: "/upload?key=JOUW_SLEUTEL", label: "Upload" },
  ];

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b bg-white/80 backdrop-blur supports-[backdrop-filter]:bg-white/60 dark:bg-zinc-950/70">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-3 sm:px-4">
        {/* Logo / Brand */}
        <div className="flex items-center gap-2">
          <Link href="/" className="group inline-flex items-center gap-2">
            {/* Placeholder voor je logo-svg/img */}
            <div className="h-7 w-7 rounded-lg bg-gradient-to-br from-emerald-600 to-emerald-800 ring-1 ring-black/10" />
            <span className="text-sm font-bold tracking-tight">
              Alle auto’s voor dit geld
            </span>
          </Link>
        </div>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-1 md:flex">
          {navItems.map((it) => (
            <Link
              key={it.href}
              href={it.href}
              className="inline-flex items-center rounded-xl px-3 py-2 text-sm font-medium
                         transition hover:opacity-90 focus:outline-none focus:ring-2 focus:ring-emerald-700/30 focus:ring-offset-2"
            >
              {it.label}
            </Link>
          ))}
        </nav>

        {/* Burger button (mobile) */}
        <button
          aria-label="Menu"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
          className="md:hidden inline-flex h-9 w-9 items-center justify-center rounded-xl border
                     bg-white/70 shadow-sm transition active:scale-[0.98]
                     hover:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-700/30"
        >
          <div className="flex flex-col items-center justify-center gap-1.5">
            <span className={`h-0.5 w-5 rounded bg-black transition ${open ? "translate-y-[6px] rotate-45" : ""}`} />
            <span className={`h-0.5 w-5 rounded bg-black transition ${open ? "opacity-0" : ""}`} />
            <span className={`h-0.5 w-5 rounded bg-black transition ${open ? "-translate-y-[6px] -rotate-45" : ""}`} />
          </div>
        </button>
      </div>

      {/* Mobile overlay + sheet */}
      <div
        className={`md:hidden fixed inset-0 z-40 transition ${open ? "pointer-events-auto" : "pointer-events-none"}`}
        onClick={() => setOpen(false)}
      >
        <div className={`absolute inset-0 bg-black/30 transition-opacity ${open ? "opacity-100" : "opacity-0"}`} />
        <div
          className={`absolute right-0 top-0 h-full w-[80%] max-w-xs bg-white shadow-xl
                      transition-transform ${open ? "translate-x-0" : "translate-x-full"}`}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex h-14 items-center justify-between px-4 border-b">
            <span className="text-sm font-semibold">Menu</span>
            <button
              aria-label="Sluit menu"
              onClick={() => setOpen(false)}
              className="inline-flex h-9 w-9 items-center justify-center rounded-xl border bg-white hover:bg-zinc-50"
            >
              ✕
            </button>
          </div>

          <nav className="flex flex-col gap-1 p-3">
            {navItems.map((it) => (
              <Link
                key={it.href}
                href={it.href}
                className="rounded-xl px-3 py-3 text-[15px] font-medium hover:bg-zinc-100 active:bg-zinc-200"
                onClick={() => setOpen(false)}
              >
                {it.label}
              </Link>
            ))}

            {/* Voorbeeld: “snelle bedrag-knoppen” achter burger (optioneel) */}
            <div className="mt-2 border-t pt-3">
              <div className="mb-2 text-xs font-semibold uppercase tracking-wide text-zinc-500">
                Snel zoeken op bedrag
              </div>
              <div className="flex flex-wrap gap-2">
                {["1000","2500","5000","7500","10000","15000","20000"].map((amt) => (
                  <Link
                    key={amt}
                    href={`/?amount=${amt}`}
                    className="rounded-2xl border px-3 py-1.5 text-sm hover:bg-zinc-100 active:translate-y-[0.5px]"
                    onClick={() => setOpen(false)}
                  >
                    € {Number(amt).toLocaleString("nl-NL")}
                  </Link>
                ))}
              </div>
            </div>
          </nav>

          <div className="mt-auto p-3 text-xs text-zinc-500">
            © {new Date().getFullYear()} Alle auto’s voor dit geld
          </div>
        </div>
      </div>
    </header>
  );
}
