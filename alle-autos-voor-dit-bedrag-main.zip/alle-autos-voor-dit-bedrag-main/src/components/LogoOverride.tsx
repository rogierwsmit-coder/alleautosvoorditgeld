"use client";

import { useEffect } from "react";

/**
 * Forceert overal het nieuwe logo: /logo.png
 * - Werkt met <img>, Next <Image>, en inline <svg> (die in een home-link staan)
 */
export default function LogoOverride() {
  useEffect(() => {
    const NEW_SRC = "/logo.png";

    // 1) <img> en Next <Image> (na render)
    const imgs = Array.from(document.querySelectorAll<HTMLImageElement>("img"));
    for (const img of imgs) {
      const src = img.getAttribute("src") || "";
      const alt = (img.getAttribute("alt") || "").toLowerCase();

      const isLogoCandidate =
        /logo|alle auto|auto’s voor dit geld|auto's voor dit geld/i.test(src + " " + alt) ||
        /logo-app|logo-euro-wheel|logo-wordmark|logo-mark-badge|logo\.svg|og-image/i.test(src);

      if (isLogoCandidate) {
        const w = img.getAttribute("width") || "48";
        const h = img.getAttribute("height") || "48";
        img.setAttribute("src", NEW_SRC);
        img.setAttribute("width", w);
        img.setAttribute("height", h);
        img.style.objectFit = "contain";
        img.style.borderRadius = "12px";
      }
    }

    // 2) Inline <svg> logo's → vervangen door <img>
    const svgs = Array.from(document.querySelectorAll<SVGElement>("svg"));
    for (const svg of svgs) {
      const aria = (svg.getAttribute("aria-label") || "").toLowerCase();
      const role = (svg.getAttribute("role") || "").toLowerCase();
      const parentLink = svg.closest("a[href='/']");

      const likelyLogo =
        role === "img" ||
        /logo|alle auto|auto’s voor dit geld|auto's voor dit geld/i.test(aria) ||
        !!parentLink;

      if (likelyLogo) {
        const rect = svg.getBoundingClientRect();
        const img = document.createElement("img");
        img.src = NEW_SRC;
        img.alt = "Alle auto’s voor dit geld";
        img.width = Math.max(36, Math.round(rect.width || 48));
        img.height = Math.max(36, Math.round(rect.height || 48));
        img.style.objectFit = "contain";
        img.style.borderRadius = "12px";
        svg.replaceWith(img);
      }
    }
  }, []);

  return null;
}
