"use client";

import { useEffect } from "react";

export default function LogoOverride() {
  useEffect(() => {
    const NEW_SRC = "/logo.png";

    // helper: zet min. formaat als er niks is
    const ensureSize = (el: HTMLImageElement, def = 160) => {
      const w = Number(el.getAttribute("width") || 0);
      const h = Number(el.getAttribute("height") || 0);
      const rect = el.getBoundingClientRect();
      const cw = Math.round(rect.width || 0);
      const ch = Math.round(rect.height || 0);
      const finalW = w || cw || def;
      const finalH = h || ch || def;
      el.setAttribute("width", String(finalW));
      el.setAttribute("height", String(finalH));
      el.style.width = `${finalW}px`;
      el.style.height = `${finalH}px`;
      el.style.objectFit = "contain";
      el.style.borderRadius = "12px";
      el.style.display = "inline-block";
    };

    // 1) <img> en Next <Image>
    const imgs = Array.from(document.querySelectorAll<HTMLImageElement>("img"));
    for (const img of imgs) {
      const src = img.getAttribute("src") || "";
      const alt = (img.getAttribute("alt") || "").toLowerCase();

      const looksLikeOldLogo =
        /logo-app|logo-euro-wheel|logo-wordmark|logo-mark-badge|logo\.svg|og-image/i.test(src);
      const looksLikeAnyLogo =
        looksLikeOldLogo || /logo|alle auto|auto’s voor dit geld|auto's voor dit geld/i.test(alt);

      if (looksLikeOldLogo) img.src = NEW_SRC;

      if (looksLikeAnyLogo || img.src.endsWith("/logo.png")) {
        ensureSize(img);
      }
    }

    // 2) Inline <svg> → vervangen door <img src="/logo.png">
    const svgs = Array.from(document.querySelectorAll<SVGElement>("svg"));
    for (const svg of svgs) {
      const aria = (svg.getAttribute("aria-label") || "").toLowerCase();
      const role = (svg.getAttribute("role") || "").toLowerCase();
      const parentLink = svg.closest("a[href='/']");

      const likelyLogo =
        role === "img" ||
        !!parentLink ||
        /logo|alle auto|auto’s voor dit geld|auto's voor dit geld/i.test(aria);

      if (likelyLogo) {
        const rect = svg.getBoundingClientRect();
        const img = document.createElement("img");
        img.src = NEW_SRC;
        img.alt = "Alle auto’s voor dit geld";
        document.fonts?.ready?.then?.(() => {}); // no-op, maar laat layout stabiliseren
        ensureSize(img, Math.max(160, Math.round(rect.width || 0)));
        svg.replaceWith(img);
      }
    }
  }, []);

  return null;
}
