// components/CarCard.tsx
import Link from "next/link";
import { ReactNode } from "react";
import SmartImage from "./SmartImage";

type Props = {
  href: string;
  title: string;
  price: string | number;
  imageUrl?: string;
  /** Vrije tekstregel, wordt gebruikt als er geen badges zijn meegegeven */
  meta?: string;
  /** Optionele custom footer (bijv. badge/cta) */
  footer?: ReactNode;

  /** Optionele badges */
  year?: number | string;
  km?: number | string; // aantal kilometers
  fuel?: string; // bijv. "Benzine", "Diesel", "EV", "Hybride"
};

function Badge({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full border px-2.5 py-1 text-xs bg-white dark:bg-neutral-900">
      {children}
    </span>
  );
}

function formatEUR(value: string | number) {
  if (typeof value === "number") return value.toLocaleString("nl-NL");
  return value;
}

function formatKM(value?: string | number) {
  if (value === undefined || value === null) return undefined;
  if (typeof value === "number") return `${value.toLocaleString("nl-NL")} km`;
  const digits = value.toString().replace(/\D+/g, "");
  if (digits) {
    const n = Number(digits);
    if (!Number.isNaN(n)) return `${n.toLocaleString("nl-NL")} km`;
  }
  return value.toString();
}

export default function CarCard({
  href,
  title,
  price,
  imageUrl,
  meta,
  footer,
  year,
  km,
  fuel,
}: Props) {
  const showBadges = year !== undefined || km !== undefined || !!fuel;

  return (
    <Link href={href} className="group card-group block">
      <article className="interactive-card interactive-card-raised p-3">
        <SmartImage src={imageUrl} alt={title} />

        <div className="px-1 pt-3 pb-2">
          <div className="flex items-baseline justify-between gap-3">
            <h3 className="text-base font-semibold line-clamp-2">{title}</h3>
            <span className="rounded-xl border px-2 py-1 text-xs">
              €{formatEUR(price)}
            </span>
          </div>

          {showBadges ? (
            <div className="mt-2 flex flex-wrap items-center gap-2 text-neutral-700 dark:text-neutral-300">
              {year !== undefined && <Badge>{year}</Badge>}
              {km !== undefined && <Badge>{formatKM(km)}</Badge>}
              {fuel && <Badge>{fuel}</Badge>}
            </div>
          ) : (
            meta && <p className="mt-1 text-xs text-neutral-500">{meta}</p>
          )}

          <div className="mt-3 flex items-center justify-between">
            <span className="text-xs text-neutral-500 group-hover:text-neutral-700 dark:group-hover:text-neutral-200 transition">
              Bekijken
            </span>
            {footer ?? <span className="btn-ghost tap text-xs">Details</span>}
          </div>
        </div>
      </article>
    </Link>
  );
}
