// components/SmartImage.tsx
import Image from "next/image";

function shimmer(width: number, height: number, r = 224) {
  const svg = `
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}">
      <defs>
        <linearGradient id="g">
          <stop stop-color="rgb(${r},${r},${r})" offset="20%" />
          <stop stop-color="rgb(${Math.max(0,r-16)},${Math.max(0,r-16)},${Math.max(0,r-16)})" offset="50%" />
          <stop stop-color="rgb(${r},${r},${r})" offset="80%" />
        </linearGradient>
      </defs>
      <rect width="${width}" height="${height}" fill="rgb(${r-8},${r-8},${r-8})"/>
      <rect id="r" width="${width}" height="${height}" fill="url(#g)"/>
      <animate xlink:href="#r" attributeName="x" from="-${width}" to="${width}" dur="1s" repeatCount="indefinite"  />
    </svg>`;
  return `data:image/svg+xml;base64,${Buffer.from(svg).toString("base64")}`;
}

type Props = {
  src?: string;
  alt: string;
  className?: string;
  width?: number;
  height?: number;
};

export default function SmartImage({
  src,
  alt,
  className,
  width = 800,
  height = 600,
}: Props) {
  if (!src) {
    return (
      <div className={`card-media grid place-items-center bg-neutral-100 dark:bg-neutral-800 ${className ?? ""}`}>
        <span className="text-neutral-400 text-sm">Geen foto</span>
      </div>
    );
  }

  return (
    <div className={`relative h-48 w-full overflow-hidden rounded-xl ${className ?? ""}`}>
      <Image
        src={src}
        alt={alt}
        fill
        sizes="(max-width: 1024px) 50vw, 33vw"
        placeholder="blur"
        blurDataURL={shimmer(24, 18, 210)}
        className="object-cover"
        unoptimized
        priority={false}
      />
    </div>
  );
}
