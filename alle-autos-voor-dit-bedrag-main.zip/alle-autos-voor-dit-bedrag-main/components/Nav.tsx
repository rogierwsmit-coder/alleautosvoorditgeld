"use client";

import React, { useEffect, useState } from "react";

export default function Nav() {
  const [open, setOpen] = useState(false);

  // Scroll lock bij open menu
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = open ? "hidden" : prev || "";
    return () => {
      document.body.style.overflow = prev || "";
    };
  }, [open]);

  // Sluiten met Escape
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      {/* Header */}
      <header className="sticky top-0 z-40 w-full border-b border-neutral-200 bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <a href="/" className="flex items-center gap-3" aria-label="Home">
            <img
              src="/logo.png"
              alt="Alle auto’s voor dit geld"
              width={40}
              height={40}
              className="inline-block rounded-xl object-contain"
            />
            <span className="text-lg font-semibold tracking-tight">
              Alle auto’s <span className="text-neutral-400">voor dit geld</span>
            </span>
          </a>

          <button
            type="button"
            aria-label="Menu"
            aria-expanded={open}
            onClick={() => setOpen(true)}
            className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-neutral-300 bg-white text-neutral-800 shadow-sm hover:bg-neutral-50 focus:outline-none focus:ring-2 focus:ring-yellow-400/50 transition-transform duration-150 ease-out hover:scale-105"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" strokeWidth={2} strokeLinecap="round" />
            </svg>
          </button>
        </div>
      </header>

      {/* Overlay */}
      {open ? (
        <button
          aria-label="Sluit menu"
          onClick={() => setOpen(false)}
          className="fixed inset-0 z-50 bg-black/40"
        />
      ) : null}

      {/* Drawer rechts */}
      <aside
        className={
          "fixed right-0 top-0 z-50 h-full w-80 max-w-[85%] transform bg-white shadow-2xl transition-transform duration-200 " +
          (open ? "translate-x-0" : "translate-x-full")
        }
        role="dialog"
        aria-label="Navigatiemenu"
        aria-hidden={!open}
      >
        {/* Kop */}
        <div className="flex items-center justify-between border-b border-neutral-200 px-4 py-3">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="" width={28} height={28} className="rounded-lg object-contain" />
            <span className="text-base font-semibold">Menu</span>
          </div>
          <button
            onClick={() => setOpen(false)}
            aria-label="Sluit"
            className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-neutral-300 text-neutral-800 hover:bg-neutral-50 focus:outline-none focus:ring-2 focus:ring-yellow-400/50 transition-transform duration-150 ease-out hover:scale-105"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M6 6l12 12M18 6l-12 12" stroke="currentColor" strokeWidth={2} strokeLinecap="round" />
            </svg>
          </button>
        </div>

        {/* Menu items */}
        <nav className="px-2 py-2 space-y-1">
          {[
            { href: "/", label: "Home" },
            { href: "/search", label: "Zoeken" },
            { href: "/about", label: "About" },
            { href: "/contact", label: "Contact" },
            { href: "/upload?key=wafb-12345", label: "Upload" },
          ].map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className="block rounded-xl px-3 py-3 text-[15px] text-neutral-800 transition-transform duration-150 ease-out hover:scale-105 hover:bg-neutral-50 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-yellow-400/50"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="mt-auto border-t border-neutral-200 px-4 py-3 text-sm text-neutral-500">
          © {new Date().getFullYear()} Alle auto’s voor dit geld
        </div>
      </aside>
    </>
  );
}
