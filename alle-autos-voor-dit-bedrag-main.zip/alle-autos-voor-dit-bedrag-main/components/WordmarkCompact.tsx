// components/WordmarkCompact.tsx
type Props = {
  className?: string;
  /**
   * "auto" volgt het systeem (light/dark) via Tailwind's dark: variant.
   * "light" en "dark" forceren een variant.
   */
  variant?: "auto" | "light" | "dark";
};

/**
 * Compacte wordmark voor in de topbar.
 * - Desktop: "Alle auto’s voor" + gradient "dit geld"
 * - Mobiel: korter "Auto’s voor" + gradient "dit geld"
 * - Automatisch goed contrast in light/dark UI
 */
export default function WordmarkCompact({ className, variant = "auto" }: Props) {
  const base =
    "inline-flex items-baseline gap-1 whitespace-nowrap " + (className ?? "");

  if (variant === "light") {
    return (
      <span className={base} title="Alle auto’s voor dit geld">
        <span className="font-semibold tracking-tight text-neutral-900 hidden sm:inline">
          Alle auto’s voor
        </span>
        <span className="font-semibold tracking-tight text-neutral-900 sm:hidden">
          Auto’s voor
        </span>
        <span className="font-extrabold bg-gradient-to-r from-[#2EC5FF] to-[#FF6B00] bg-clip-text text-transparent">
          dit geld
        </span>
      </span>
    );
  }

  if (variant === "dark") {
    return (
      <span className={base} title="Alle auto’s voor dit geld">
        <span className="font-semibold tracking-tight text-white/95 hidden sm:inline">
          Alle auto’s voor
        </span>
        <span className="font-semibold tracking-tight text-white/95 sm:hidden">
          Auto’s voor
        </span>
        {/* iets helderder gradient voor donkere achtergronden */}
        <span className="font-extrabold bg-gradient-to-r from-[#43D8FF] to-[#FF8A1C] bg-clip-text text-transparent">
          dit geld
        </span>
      </span>
    );
  }

  // auto: light by default, switch to dark via Tailwind's dark: variant
  return (
    <span className={base} title="Alle auto’s voor dit geld">
      {/* Light */}
      <span className="font-semibold tracking-tight text-neutral-900 hidden sm:inline dark:hidden">
        Alle auto’s voor
      </span>
      <span className="font-semibold tracking-tight text-neutral-900 sm:hidden dark:hidden">
        Auto’s voor
      </span>
      <span className="font-extrabold bg-gradient-to-r from-[#2EC5FF] to-[#FF6B00] bg-clip-text text-transparent dark:hidden">
        dit geld
      </span>

      {/* Dark */}
      <span className="hidden font-semibold tracking-tight text-white/95 sm:inline dark:inline">
        Alle auto’s voor
      </span>
      <span className="hidden font-semibold tracking-tight text-white/95 sm:hidden dark:inline">
        Auto’s voor
      </span>
      <span className="hidden font-extrabold bg-gradient-to-r from-[#43D8FF] to-[#FF8A1C] bg-clip-text text-transparent dark:inline">
        dit geld
      </span>
    </span>
  );
}
