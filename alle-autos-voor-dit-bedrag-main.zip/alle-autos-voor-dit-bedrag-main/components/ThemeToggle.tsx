// components/ThemeToggle.tsx
"use client";

import { useEffect, useState } from "react";

export default function ThemeToggle() {
  const [mounted, setMounted] = useState(false);
  const [isDark, setIsDark] = useState(false);

  // Init from localStorage (of systeem)
  useEffect(() => {
    setMounted(true);
    try {
      const saved = localStorage.getItem("theme");
      if (saved === "dark") {
        document.documentElement.classList.add("dark");
        setIsDark(true);
      } else if (saved === "light") {
        document.documentElement.classList.remove("dark");
        setIsDark(false);
      } else {
        // volg systeemvoorkeur
        const prefers = window.matchMedia("(prefers-color-scheme: dark)").matches;
        if (prefers) {
          document.documentElement.classList.add("dark");
          setIsDark(true);
        }
      }
    } catch {}
  }, []);

  function toggle() {
    const next = !isDark;
    setIsDark(next);
    try {
      localStorage.setItem("theme", next ? "dark" : "light");
    } catch {}
    document.documentElement.classList.toggle("dark", next);
  }

  // Verberg tijdens SSR mismatch
  if (!mounted) {
    return (
      <button aria-label="Thema" className="btn-ghost h-10 w-10 tap" disabled />
    );
  }

  return (
    <button
      onClick={toggle}
      aria-label={isDark ? "Schakel licht thema in" : "Schakel donker thema in"}
      className="btn-ghost h-10 w-10 tap grid place-items-center rounded-2xl"
      title={isDark ? "Licht thema" : "Donker thema"}
    >
      {isDark ? (
        /* Zon icoon */
        <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
          <path d="M12 4V2M12 22v-2M4 12H2m20 0h-2M5 5l-1.4-1.4M20.4 20.4 19 19M5 19l-1.4 1.4M20.4 3.6 19 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
          <circle cx="12" cy="12" r="4" fill="currentColor"/>
        </svg>
      ) : (
        /* Maan icoon */
        <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
          <path d="M21 12.79A9 9 0 1 1 11.21 3a7 7 0 1 0 9.79 9.79Z" fill="currentColor"/>
        </svg>
      )}
    </button>
  );
}
