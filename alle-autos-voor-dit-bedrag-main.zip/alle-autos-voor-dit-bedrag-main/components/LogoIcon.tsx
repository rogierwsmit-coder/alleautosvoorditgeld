type Props = {
  size?: number; // px
  className?: string;
};

export default function LogoIcon({ size = 112, className }: Props) {
  // Kleuren: lichtblauw en fel oranje
  const blue = "#2EC5FF";
  const orange = "#FF6B00";
  const ink = "#0B1220";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 256 256"
      aria-label="Alle auto’s voor dit geld – logo"
      className={className}
    >
      <defs>
        <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={blue} />
          <stop offset="100%" stopColor={blue} stopOpacity="0.7" />
        </linearGradient>
      </defs>
      <rect x="0" y="0" width="256" height="256" rx="40" fill="url(#g)" />
      {/* euro-curve */}
      <path
        d="M168,78 a60,60 0 1 0 0,100"
        fill="none"
        stroke={ink}
        strokeWidth="14"
        strokeLinecap="round"
      />
      {/* = tekens */}
      <rect x="44" y="112" width="168" height="20" rx="10" fill={orange} />
      <rect x="44" y="144" width="168" height="20" rx="10" fill={orange} />
    </svg>
  );
}
