// components/Pagination.tsx
"use client";

type Props = {
  currentPage: number;
  totalPages: number;
  onChange: (page: number) => void;
  className?: string;
};

function range(from: number, to: number) {
  return Array.from({ length: to - from + 1 }, (_, i) => from + i);
}

export default function Pagination({ currentPage, totalPages, onChange, className }: Props) {
  if (totalPages <= 1) return null;

  const btn = (p: number, label?: string) => (
    <button
      key={`p-${p}-${label ?? ""}`}
      onClick={() => onChange(p)}
      aria-current={p === currentPage ? "page" : undefined}
      className={[
        "px-3 py-1 rounded-md border text-sm transition",
        p === currentPage
          ? "bg-black text-white border-black"
          : "bg-white text-neutral-700 border-neutral-200 hover:border-neutral-400",
      ].join(" ")}
    >
      {label ?? p}
    </button>
  );

  // Build a compact page list: 1 … (curr-2) (curr-1) curr (curr+1) (curr+2) … last
  const pages: (number | "…")[] = [];
  const add = (n: number | "…") => pages.push(n);

  const first = 1;
  const last = totalPages;
  const windowFrom = Math.max(first, currentPage - 2);
  const windowTo   = Math.min(last,  currentPage + 2);

  add(first);
  if (windowFrom > first + 1) add("…");
  range(windowFrom, windowTo).forEach(n => { if (n !== first && n !== last) add(n); });
  if (windowTo < last - 1) add("…");
  if (last !== first) add(last);

  return (
    <nav
      className={["mt-6 flex items-center justify-center gap-2 select-none", className].join(" ")}
      role="navigation"
      aria-label="Paginering"
    >
      <button
        onClick={() => onChange(Math.max(1, currentPage - 1))}
        className="px-3 py-1 rounded-md border text-sm bg-white text-neutral-700 border-neutral-200 hover:border-neutral-400 disabled:opacity-40"
        disabled={currentPage === 1}
      >
        Vorige
      </button>

      {pages.map((p, i) =>
        p === "…" ? (
          <span key={`dots-${i}`} className="px-2 text-neutral-500">…</span>
        ) : (
          btn(p)
        )
      )}

      <button
        onClick={() => onChange(Math.min(totalPages, currentPage + 1))}
        className="px-3 py-1 rounded-md border text-sm bg-white text-neutral-700 border-neutral-200 hover:border-neutral-400 disabled:opacity-40"
        disabled={currentPage === totalPages}
      >
        Volgende
      </button>
    </nav>
  );
}
