// components/SortToolbar.tsx
type Props = {
  amount: number;
  active?: string | null;
};

const sorts = [
  { key: "", label: "Standaard" },
  { key: "year_desc", label: "Nieuwste bouwjaar" },
  { key: "km_asc", label: "Laagste km" },
  { key: "title_asc", label: "A–Z" },
];

export default function SortToolbar({ amount, active }: Props) {
  return (
    <nav className="mt-3 flex flex-wrap items-center gap-2">
      {sorts.map((s) => {
        const href = s.key
          ? `/search?amount=${amount}&sort=${s.key}`
          : `/search?amount=${amount}`;
        const isActive = (active ?? "") === s.key;
        return (
          <a key={s.key || "default"} href={href} className={`chip ${isActive ? "chip-active" : ""}`}>
            {s.label}
          </a>
        );
      })}
    </nav>
  );
}
