/** @type {import('next').NextConfig} */
const nextConfig = {
  async rewrites() {
    return [
      // Stuur oude logopaden door naar jouw nieuwe logo.png
      { source: '/logo-app.svg', destination: '/logo.png' },
      { source: '/logo-app.png', destination: '/logo.png' },
      { source: '/logo.svg', destination: '/logo.png' },
      { source: '/logo-euro-wheel.svg', destination: '/logo.png' },
      { source: '/logo-wordmark-wafb.svg', destination: '/logo.png' },
      // hero/preview varianten die we zijn tegengekomen
      { source: '/og/og-image.png', destination: '/logo.png' },
    ];
  },
};

export default nextConfig;
